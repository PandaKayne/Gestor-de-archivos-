# Gestor de Archivos

Gestor de archivos para Android: **código abierto, sin anuncios, sin telemetría**.

## Qué incluye (v0.1)
- Categorías: almacenamiento interno, tarjeta SD, descargas, imágenes, audio, vídeos, documentos
- Extraer ZIP, RAR, 7Z, TAR, TAR.GZ/TGZ y GZ (con protección contra "zip slip")
- **Papelera de reciclaje**: restaurar, eliminar definitivamente, vaciar y autolimpieza a los 30 días
- Abrir archivos con otras apps

## Cómo compilar
1. Abre la carpeta en **Android Studio** (Koala o superior) y deja que sincronice Gradle.
2. Ejecuta en un móvil o emulador (Android 8.0+).
3. Concede "Acceso a todos los archivos" cuando la app lo pida.

## Hoja de ruta
- [ ] Copiar / mover / renombrar / crear carpeta, selección múltiple
- [ ] Buscador y ordenación
- [ ] Comprimir a ZIP / 7Z (con contraseña)
- [ ] Doble panel
- [ ] Detector de duplicados y analizador de archivos grandes
- [ ] Bóveda cifrada
- [ ] FTP / SFTP / SMB / WebDAV
- [ ] Ajustes (tamaño GB/MB, formato de fecha, aviso de almacenamiento lleno, detectar USB)
- [ ] Miniaturas, reproductor integrado

## Licencia
Se recomienda GPLv3. Añade el texto oficial como `LICENSE` (https://www.gnu.org/licenses/gpl-3.0.txt).
Distribución: GitHub Releases y F-Droid. Google Play restringe el permiso de acceso total a archivos.
