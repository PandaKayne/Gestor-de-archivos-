# Gestor de Archivos

**Compatible con Android 9 a 16** (API 28 a 36). Probado en teoría con Android 12; falta probarlo en el resto.

Gestor de archivos para Android: **código abierto, sin anuncios, sin telemetría**.

## Qué incluye (v0.6)
- Música en segundo plano (servicio con notificación y barra de control en la app)
- Reproductor de vídeo con velocidad de reproducción
- Colores de tema: azul, gris, rojo y verde (además de claro/oscuro)
- Icono nuevo: carpeta con lupa
- Compilación optimizada (R8, recursos reducidos)

### Incluido desde v0.5
- Edición de PDF: dibujar, resaltar y escribir texto encima; rotar, borrar y extraer páginas; unir y dividir; fotos a PDF; rellenar formularios
- Detección de memorias USB (OTG) y tarjetas SD al conectarlas o quitarlas
- Lectores: ODT/ODS/ODP, EPUB (texto) y contenido de ZIP/RAR/7Z/TAR sin extraer

### Incluido desde v0.4
- Lector de PDF (páginas con zoom) y lector de texto de Word, Excel y PowerPoint (.docx, .xlsx, .pptx)

### Incluido desde v0.3
- Visor de imágenes (deslizar entre fotos, zoom con dos dedos y doble toque)
- Reproductor integrado de audio y vídeo (Media3/ExoPlayer) con lista de la carpeta, aleatorio y repetir
- Editor de texto, crear carpetas y archivos, renombrar, copiar y mover

### Incluido desde v0.2
- Pantalla de inicio con GB usados / total del almacenamiento interno y la tarjeta SD (con barra)
- Categorías con tamaño y número de archivos: Descargas, Imágenes, Audio, Vídeos, Documentos, APK y Nuevos archivos
- Ajustes: tema claro/oscuro, papelera, confirmación, archivos ocultos, unidad de tamaño y orden
- Explorador con búsqueda, % utilizado, nº de elementos y fecha de cada carpeta
- Categorías: almacenamiento interno, tarjeta SD, descargas, imágenes, audio, vídeos, documentos
- Extraer ZIP, RAR, 7Z, TAR, TAR.GZ/TGZ y GZ (con protección contra "zip slip")
- **Papelera de reciclaje**: restaurar, eliminar definitivamente, vaciar y autolimpieza a los 30 días
- Abrir archivos con otras apps

## Cómo compilar
1. Abre la carpeta en **Android Studio** (Koala o superior) y deja que sincronice Gradle.
2. Ejecuta en un móvil o emulador (Android 8.0+).
3. Concede "Acceso a todos los archivos" cuando la app lo pida.

## Hoja de ruta
- [ ] Copiar / mover / renombrar / crear carpeta, selección múltiple
- [ ] Buscador y ordenación
- [ ] Comprimir a ZIP / 7Z (con contraseña)
- [ ] Doble panel
- [ ] Detector de duplicados y analizador de archivos grandes
- [ ] Bóveda cifrada
- [ ] FTP / SFTP / SMB / WebDAV
- [ ] Nube, acceso remoto y acceso desde PC
- [ ] Aviso de almacenamiento lleno y detección de USB
- [ ] Miniaturas, reproductor integrado

## Licencia
Se recomienda GPLv3. Añade el texto oficial como `LICENSE` (https://www.gnu.org/licenses/gpl-3.0.txt).
Distribución: GitHub Releases y F-Droid. Google Play restringe el permiso de acceso total a archivos.
