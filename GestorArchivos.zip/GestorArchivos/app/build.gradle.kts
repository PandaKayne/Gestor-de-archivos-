plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.gestor.archivos"
    compileSdk = 34

    defaultConfig {
        applicationId = "org.gestor.archivos"
        minSdk = 28
        targetSdk = 34
        versionCode = 8
        versionName = "0.6.2"
        resourceConfigurations += listOf("es", "en")
    }
    buildTypes {
        // Optimizado: código y recursos reducidos (R8). Firmado con la clave de depuración para poder instalarlo.
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")

    // Reproductor de audio y vídeo (con servicio para música en segundo plano)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")

    // Edición de PDF (anotar, unir, dividir, formularios)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")

    // Compresión / extracción
    implementation("org.apache.commons:commons-compress:1.26.2") // 7z, tar, gz, zip
    implementation("org.tukaani:xz:1.9")                           // soporte 7z/xz
    implementation("com.github.junrar:junrar:7.5.5")               // extraer RAR
}
