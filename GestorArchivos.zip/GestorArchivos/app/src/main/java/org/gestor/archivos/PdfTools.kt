package org.gestor.archivos

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDComboBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDListBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import com.tom_roush.pdfbox.util.Matrix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

// ------------------------------------------------------------ Modelo de anotaciones
// Coordenadas en "unidades de ancho de página": x e y se miden como fracción del ANCHO visible.
sealed interface Annot
data class Ink(val pts: List<Offset>, val argb: Int, val w: Float, val hl: Boolean) : Annot
data class TextNote(val x: Float, val y: Float, val text: String, val argb: Int, val size: Float) : Annot
enum class Tool { MOVE, PEN, HL, TEXT }

data class FormField(val name: String, val kind: Int, val options: List<String>, val initial: String)

// ------------------------------------------------------------ Operaciones con PDFBox
object PdfEdit {

    private fun parts(argb: Int) = Triple((argb shr 16) and 255, (argb shr 8) and 255, argb and 255)

    private fun latin(s: String): String = buildString {
        for (c in s) append(if (c.code in 32..126 || c.code in 160..255) c else '?')
    }

    /** Dibuja las anotaciones encima de las páginas y guarda una copia nueva. */
    fun annotate(src: File, out: File, edits: Map<Int, List<Annot>>) {
        PDDocument.load(src).use { doc ->
            for ((pi, list) in edits) {
                if (list.isEmpty() || pi < 0 || pi >= doc.numberOfPages) continue
                val page = doc.getPage(pi)
                val box = page.cropBox
                val w = box.width
                val h = box.height
                val rot = ((page.rotation % 360) + 360) % 360
                val wv = if (rot == 90 || rot == 270) h else w
                val map: (Float, Float) -> Pair<Float, Float> = { x, y ->
                    val px = x * wv
                    val py = y * wv
                    val r = when (rot) {
                        90 -> py to px
                        180 -> (w - px) to py
                        270 -> (w - py) to (h - px)
                        else -> px to (h - py)
                    }
                    (r.first + box.lowerLeftX) to (r.second + box.lowerLeftY)
                }
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    for (a in list) {
                        when (a) {
                            is Ink -> drawInk(cs, a, wv, map)
                            is TextNote -> drawNote(cs, a, wv, rot, map)
                        }
                    }
                }
            }
            doc.save(out)
        }
    }

    private fun drawInk(cs: PDPageContentStream, a: Ink, wv: Float, map: (Float, Float) -> Pair<Float, Float>) {
        if (a.pts.isEmpty()) return
        val (r, g, b) = parts(a.argb)
        cs.saveGraphicsState()
        if (a.hl) {
            val gs = PDExtendedGraphicsState()
            gs.setStrokingAlphaConstant(0.35f)
            gs.setNonStrokingAlphaConstant(0.35f)
            cs.setGraphicsStateParameters(gs)
        }
        cs.setStrokingColor(r, g, b)
        cs.setLineWidth(a.w * wv)
        cs.setLineCapStyle(if (a.hl) 0 else 1)
        cs.setLineJoinStyle(1)
        val first = map(a.pts[0].x, a.pts[0].y)
        cs.moveTo(first.first, first.second)
        if (a.pts.size == 1) {
            cs.lineTo(first.first + 0.01f, first.second)
        } else {
            for (k in 1 until a.pts.size) {
                val p = map(a.pts[k].x, a.pts[k].y)
                cs.lineTo(p.first, p.second)
            }
        }
        cs.stroke()
        cs.restoreGraphicsState()
    }

    private fun drawNote(cs: PDPageContentStream, a: TextNote, wv: Float, rot: Int, map: (Float, Float) -> Pair<Float, Float>) {
        val (r, g, b) = parts(a.argb)
        cs.setNonStrokingColor(r, g, b)
        a.text.split('\n').forEachIndexed { i, line ->
            val p = map(a.x, a.y + a.size * 0.8f + i * a.size * 1.2f)
            cs.beginText()
            cs.setFont(PDType1Font.HELVETICA, a.size * wv)
            cs.setTextMatrix(Matrix.getRotateInstance(Math.toRadians(rot.toDouble()), p.first, p.second))
            cs.showText(latin(line))
            cs.endText()
        }
    }

    /** Guarda una copia con solo las páginas de [keep], aplicando los giros indicados (índice original -> grados). */
    fun savePages(src: File, out: File, keep: Set<Int>, rotations: Map<Int, Int>) {
        PDDocument.load(src).use { doc ->
            for ((i, d) in rotations) {
                if (i in 0 until doc.numberOfPages) {
                    val p = doc.getPage(i)
                    p.rotation = (((p.rotation + d) % 360) + 360) % 360
                }
            }
            for (i in doc.numberOfPages - 1 downTo 0) {
                if (i !in keep) doc.removePage(i)
            }
            doc.save(out)
        }
    }

    fun merge(files: List<File>, out: File) {
        val m = PDFMergerUtility()
        m.destinationFileName = out.absolutePath
        for (f in files) m.addSource(f)
        m.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly())
    }

    fun splitAll(src: File, outDir: File): Int {
        outDir.mkdirs()
        return PDDocument.load(src).use { doc ->
            val partsList = Splitter().split(doc)
            partsList.forEachIndexed { i, d ->
                d.use { it.save(File(outDir, "${src.nameWithoutExtension}_p${i + 1}.pdf")) }
            }
            partsList.size
        }
    }

    fun imagesToPdf(images: List<File>, out: File) {
        PDDocument().use { doc ->
            for (img in images) {
                val bmp = decodeSampled(img, 2000) ?: continue
                val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                val c = AndroidCanvas(flat)
                c.drawColor(AndroidColor.WHITE)
                c.drawBitmap(bmp, 0f, 0f, null)
                val bos = ByteArrayOutputStream()
                flat.compress(Bitmap.CompressFormat.JPEG, 88, bos)
                val x = JPEGFactory.createFromStream(doc, ByteArrayInputStream(bos.toByteArray()))
                val pw = 595f
                val ph = pw * flat.height / flat.width
                val page = PDPage(PDRectangle(pw, ph))
                doc.addPage(page)
                PDPageContentStream(doc, page).use { cs -> cs.drawImage(x, 0f, 0f, pw, ph) }
                bmp.recycle()
                flat.recycle()
            }
            if (doc.numberOfPages == 0) error("No se pudo leer ninguna imagen")
            doc.save(out)
        }
    }

    fun readForm(src: File): List<FormField> {
        return PDDocument.load(src).use { doc ->
            val form = doc.documentCatalog.acroForm ?: return@use emptyList<FormField>()
            val out = ArrayList<FormField>()
            for (f in form.fieldTree) {
                val name = f.fullyQualifiedName ?: continue
                when (f) {
                    is PDTextField -> out.add(FormField(name, 0, emptyList(), f.getValue() ?: ""))
                    is PDCheckBox -> out.add(FormField(name, 1, emptyList(), if (f.isChecked) "true" else "false"))
                    is PDComboBox -> out.add(FormField(name, 2, f.getOptions(), f.getValue().firstOrNull() ?: ""))
                    is PDListBox -> out.add(FormField(name, 2, f.getOptions(), f.getValue().firstOrNull() ?: ""))
                    is PDRadioButton -> out.add(FormField(name, 2, f.getExportValues(), f.getValue() ?: ""))
                }
            }
            out
        }
    }

    fun fillForm(src: File, out: File, values: Map<String, String>) {
        PDDocument.load(src).use { doc ->
            val form = doc.documentCatalog.acroForm ?: error("Este PDF no tiene formulario")
            for ((name, v) in values) {
                val f = form.getField(name) ?: continue
                try {
                    when (f) {
                        is PDCheckBox -> if (v == "true") f.check() else f.unCheck()
                        is PDComboBox -> f.setValue(v)
                        is PDListBox -> f.setValue(v)
                        is PDRadioButton -> if (v.isNotEmpty()) f.setValue(v)
                        is PDTextField -> f.setValue(v)
                    }
                } catch (e: Exception) {
                    // un campo problemático no debe impedir guardar los demás
                }
            }
            form.setNeedAppearances(true)
            doc.save(out)
        }
    }
}

// ------------------------------------------------------------ Pantalla: administrar páginas
data class PItem(val index: Int, val rot: Int)

@Composable
fun PdfPagesScreen(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val doc = remember(file) { runCatching { PdfDoc(file) } }
    DisposableEffect(file) { onDispose { doc.getOrNull()?.close() } }
    val d = doc.getOrNull()
    val pages = remember(file) {
        val l = mutableStateListOf<PItem>()
        if (d != null) {
            for (i in 0 until d.pageCount) l.add(PItem(i, 0))
        }
        l
    }
    val selected = remember(file) { mutableStateListOf<Int>() }
    BackHandler(onBack = onBack)

    fun saveCopy(only: Set<Int>?, suffix: String) {
        val keep = only ?: pages.map { it.index }.toSet()
        val rots = HashMap<Int, Int>()
        for (p in pages) if (p.rot != 0) rots[p.index] = p.rot
        scope.launch {
            val out = uniqueFile(file.parentFile!!, file.nameWithoutExtension + " ($suffix).pdf")
            val r = withContext(Dispatchers.IO) { runCatching { PdfEdit.savePages(file, out, keep, rots) } }
            toast(ctx, if (r.isSuccess) "Guardado: ${out.name}" else "Error: ${r.exceptionOrNull()?.message}")
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header("Páginas · ${file.name}", onBack)
        if (d == null) {
            Text("No se puede abrir este PDF (puede tener contraseña).", Modifier.padding(16.dp))
        } else {
            Text(
                "Toca páginas para seleccionarlas. Sin selección, «Rotar» afecta a todas. Los cambios se guardan en una copia.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(pages.size) { k ->
                    val pg = pages[k]
                    PageThumb(d, pg, pg.index in selected, k + 1) {
                        if (pg.index in selected) selected.remove(pg.index) else selected.add(pg.index)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = {
                    for (k in pages.indices) {
                        if (selected.isEmpty() || pages[k].index in selected) {
                            pages[k] = pages[k].copy(rot = (pages[k].rot + 90) % 360)
                        }
                    }
                }) { Text("⟳ Rotar") }
                TextButton(onClick = {
                    if (selected.isEmpty()) {
                        toast(ctx, "Selecciona primero las páginas a borrar")
                    } else if (selected.size >= pages.size) {
                        toast(ctx, "No puedes borrar todas las páginas")
                    } else {
                        pages.removeAll { p -> p.index in selected }
                        selected.clear()
                    }
                }) { Text("🗑 Borrar") }
                TextButton(onClick = {
                    if (selected.isEmpty()) toast(ctx, "Selecciona las páginas a extraer")
                    else saveCopy(selected.toSet(), "extraído")
                }) { Text("✂ Extraer") }
                TextButton(onClick = { saveCopy(null, "editado") }) { Text("💾 Guardar") }
            }
        }
    }
}

@Composable
fun PageThumb(doc: PdfDoc, item: PItem, selected: Boolean, label: Int, onClick: () -> Unit) {
    var bmp by remember(item.index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.index) {
        bmp = withContext(Dispatchers.IO) { runCatching { doc.render(item.index, 300) }.getOrNull() }
    }
    val bg = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f) else Color.Gray.copy(alpha = 0.2f)
    Box(
        Modifier.padding(4.dp).height(190.dp).fillMaxWidth().background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            val s = if (item.rot % 180 != 0) 0.65f else 1f
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Página $label",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(6.dp)
                    .graphicsLayer(rotationZ = item.rot.toFloat(), scaleX = s, scaleY = s)
            )
        } else {
            CircularProgressIndicator()
        }
        Text("$label", Modifier.align(Alignment.BottomCenter).padding(2.dp), style = MaterialTheme.typography.labelMedium)
        if (selected) Text("✔", Modifier.align(Alignment.TopEnd).padding(6.dp), fontSize = 18.sp)
    }
}

// ------------------------------------------------------------ Pantalla: rellenar formulario
@Composable
fun PdfFormScreen(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var fields by remember(file) { mutableStateOf<List<FormField>?>(null) }
    var failure by remember(file) { mutableStateOf<String?>(null) }
    val values = remember(file) { mutableStateMapOf<String, String>() }
    LaunchedEffect(file) {
        val r = withContext(Dispatchers.IO) { runCatching { PdfEdit.readForm(file) } }
        if (r.isSuccess) {
            val l = r.getOrThrow()
            for (f in l) values[f.name] = f.initial
            fields = l
        } else {
            failure = r.exceptionOrNull()?.message ?: "Error desconocido"
        }
    }
    BackHandler(onBack = onBack)
    val list = fields
    val fail = failure

    fun save() {
        val l = list ?: return
        val changed = HashMap<String, String>()
        for (f in l) {
            val v = values[f.name] ?: f.initial
            if (v != f.initial) changed[f.name] = v
        }
        if (changed.isEmpty()) {
            toast(ctx, "No hay cambios que guardar")
            return
        }
        scope.launch {
            val out = uniqueFile(file.parentFile!!, file.nameWithoutExtension + " (rellenado).pdf")
            val r = withContext(Dispatchers.IO) { runCatching { PdfEdit.fillForm(file, out, changed) } }
            toast(
                ctx,
                if (r.isSuccess) "Guardado: ${out.name}. Si no ves los datos, ábrelo con otra app." else "Error: ${r.exceptionOrNull()?.message}"
            )
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header("Formulario", onBack) {
            TextButton(onClick = { save() }, enabled = !list.isNullOrEmpty()) { Text("Guardar copia") }
        }
        if (fail != null) {
            Text("No se pudo leer el formulario: $fail", Modifier.padding(16.dp))
        } else if (list == null) {
            Text("Cargando…", Modifier.padding(16.dp))
        } else if (list.isEmpty()) {
            Text(
                "Este PDF no tiene campos de formulario rellenables. Ábrelo y usa ✏️ → 🔤 para escribir texto encima.",
                Modifier.padding(16.dp)
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list) { f ->
                    when (f.kind) {
                        0 -> OutlinedTextField(
                            value = values[f.name] ?: "",
                            onValueChange = { values[f.name] = it },
                            label = { Text(f.name) },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                        )
                        1 -> SwitchRow(f.name, null, values[f.name] == "true") { values[f.name] = if (it) "true" else "false" }
                        else -> ChoiceRow(f.name, f.options, f.options.indexOf(values[f.name] ?: "")) {
                            values[f.name] = f.options[it]
                        }
                    }
                }
            }
        }
    }
}
