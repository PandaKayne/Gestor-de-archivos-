package org.gestor.archivos

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import java.io.File
import java.util.Locale

/** Tamaño legible (base 1000, como muestra Android). Respeta el ajuste de unidad. */
fun formatSize(b: Long): String {
    val loc = Locale.getDefault()
    return when (Prefs.sizeUnit) {
        1 -> String.format(loc, "%.2f GB", b / 1e9)
        2 -> String.format(loc, "%.1f MB", b / 1e6)
        else -> {
            if (b < 1000) {
                "$b B"
            } else {
                val u = arrayOf("KB", "MB", "GB", "TB")
                var v = b / 1000.0
                var i = 0
                while (v >= 1000 && i < u.size - 1) {
                    v /= 1000
                    i++
                }
                String.format(loc, "%.1f %s", v, u[i])
            }
        }
    }
}

data class Space(val used: Long, val total: Long) {
    val fraction: Float get() = if (total > 0) used.toFloat() / total else 0f
    val percent: Int get() = (fraction * 100).toInt()
}

fun spaceOf(dir: File): Space? = try {
    val s = StatFs(dir.absolutePath)
    val t = s.totalBytes
    Space(t - s.availableBytes, t)
} catch (e: Exception) {
    null
}

fun internalRoot(): File = Environment.getExternalStorageDirectory()

fun sdRoot(ctx: Context): File? =
    ctx.getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
        ?.absolutePath?.substringBefore("/Android")?.let { File(it) }

// ------------------------------------------------------------ Categorías
data class Cat(
    val id: String,
    val emoji: String,
    val label: String,
    val where: String,
    val args: List<String> = emptyList()
)

private const val BASE = "_data NOT LIKE ? AND _data NOT LIKE ? AND _size > 0"
private val BASE_ARGS = listOf("%/.%", "%/Android/%")

private const val DOCS = "(mime_type LIKE 'text/%' OR mime_type = 'application/pdf' " +
        "OR mime_type = 'application/msword' OR (mime_type LIKE 'application/vnd.%' " +
        "AND mime_type != 'application/vnd.android.package-archive'))"

fun categories(): List<Cat> {
    val since = System.currentTimeMillis() / 1000 - 7 * 86400
    val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath + "/%"
    return listOf(
        Cat("downloads", "⬇️", "Descargas", "_data LIKE ?", listOf(dl)),
        Cat("images", "🖼️", "Imágenes", "media_type = 1"),
        Cat("audio", "🎵", "Audio", "media_type = 2"),
        Cat("videos", "🎬", "Vídeos", "media_type = 3"),
        Cat("docs", "📄", "Documentos", DOCS),
        Cat("apps", "🤖", "Aplicaciones (APK)", "mime_type = 'application/vnd.android.package-archive'"),
        Cat("new", "🆕", "Nuevos archivos (7 días)", "date_added >= ?", listOf(since.toString()))
    )
}

private fun Cat.selection() = "($where) AND $BASE"
private fun Cat.selArgs(): Array<String> = (args + BASE_ARGS).toTypedArray()

private fun filesUri() = MediaStore.Files.getContentUri("external")

/** Devuelve (bytes totales, número de archivos) de la categoría. */
fun catStats(ctx: Context, c: Cat): Pair<Long, Int> {
    var size = 0L
    var n = 0
    ctx.contentResolver.query(filesUri(), arrayOf("_size"), c.selection(), c.selArgs(), null)?.use { cur ->
        while (cur.moveToNext()) {
            size += cur.getLong(0)
            n++
        }
    }
    return size to n
}

fun catFiles(ctx: Context, c: Cat, limit: Int = 1500): List<File> {
    val out = ArrayList<File>()
    ctx.contentResolver.query(filesUri(), arrayOf("_data"), c.selection(), c.selArgs(), "date_modified DESC")?.use { cur ->
        while (cur.moveToNext() && out.size < limit) {
            val path = cur.getString(0)
            if (path != null) {
                val f = File(path)
                if (f.isFile) out.add(f)
            }
        }
    }
    return out
}

// ------------------------------------------------------------ Utilidades
/** Elimina respetando el ajuste de papelera. */
fun removeFile(f: File) {
    if (Prefs.useTrash) {
        TrashManager.moveToTrash(f)
    } else if (!f.deleteRecursively()) {
        error("No se pudo eliminar ${f.name}")
    }
}

fun stripExt(name: String): String {
    val l = name.lowercase()
    for (e in listOf(".tar.gz", ".tgz", ".zip", ".rar", ".7z", ".tar", ".gz")) {
        if (l.endsWith(e)) return name.dropLast(e.length)
    }
    return name
}
