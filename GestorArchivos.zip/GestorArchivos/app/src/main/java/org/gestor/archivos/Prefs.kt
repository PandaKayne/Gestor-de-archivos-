package org.gestor.archivos

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Ajustes de la app (se guardan en SharedPreferences y refrescan la interfaz al cambiar). */
object Prefs {
    private var sp: SharedPreferences? = null

    var theme by mutableIntStateOf(0)        // 0 sistema, 1 claro, 2 oscuro
        private set
    var useTrash by mutableStateOf(true)
        private set
    var confirmDelete by mutableStateOf(true)
        private set
    var showHidden by mutableStateOf(false)
        private set
    var trashDays by mutableIntStateOf(30)
        private set
    var sizeUnit by mutableIntStateOf(0)     // 0 automática, 1 GB, 2 MB
        private set
    var sort by mutableIntStateOf(0)         // 0 nombre, 1 fecha, 2 tamaño
        private set
    var accent by mutableIntStateOf(0)       // 0 predeterminado, 1 azul, 2 gris, 3 rojo, 4 verde
        private set

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("gestor_prefs", Context.MODE_PRIVATE)
        sp = p
        theme = p.getInt("theme", 0)
        useTrash = p.getBoolean("useTrash", true)
        confirmDelete = p.getBoolean("confirmDelete", true)
        showHidden = p.getBoolean("showHidden", false)
        trashDays = p.getInt("trashDays", 30)
        sizeUnit = p.getInt("sizeUnit", 0)
        sort = p.getInt("sort", 0)
        accent = p.getInt("accent", 0)
    }

    fun putTheme(v: Int) { theme = v; sp?.edit()?.putInt("theme", v)?.apply() }
    fun putUseTrash(v: Boolean) { useTrash = v; sp?.edit()?.putBoolean("useTrash", v)?.apply() }
    fun putConfirmDelete(v: Boolean) { confirmDelete = v; sp?.edit()?.putBoolean("confirmDelete", v)?.apply() }
    fun putShowHidden(v: Boolean) { showHidden = v; sp?.edit()?.putBoolean("showHidden", v)?.apply() }
    fun putTrashDays(v: Int) { trashDays = v; sp?.edit()?.putInt("trashDays", v)?.apply() }
    fun putSizeUnit(v: Int) { sizeUnit = v; sp?.edit()?.putInt("sizeUnit", v)?.apply() }
    fun putSort(v: Int) { sort = v; sp?.edit()?.putInt("sort", v)?.apply() }
    fun putAccent(v: Int) { accent = v; sp?.edit()?.putInt("accent", v)?.apply() }
}
