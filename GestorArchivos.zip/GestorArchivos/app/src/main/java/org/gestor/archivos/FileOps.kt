package org.gestor.archivos

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

enum class Kind { IMAGE, VIDEO, AUDIO, TEXT, PDF, OFFICE, ARCHIVE, OTHER }

private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
private val VID = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "ts", "flv", "mpg", "mpeg", "wmv")
private val AUD = setOf(
    "mp3", "flac", "ogg", "oga", "opus", "wav", "m4a", "aac", "amr", "mka", "wma",
    "ape", "ac3", "mid", "midi", "3ga", "wv", "mp2", "aiff", "aif"
)
private val TXT = setOf(
    "txt", "md", "json", "xml", "csv", "tsv", "log", "html", "htm", "css", "js", "kt", "kts", "java",
    "py", "yml", "yaml", "ini", "conf", "cfg", "properties", "sh", "srt", "vtt", "lrc", "gradle",
    "c", "cpp", "h", "sql", "gitignore"
)

private val OFFICE_EXT = setOf("docx", "xlsx", "pptx", "odt", "ods", "odp", "epub")
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz", "tgz")

fun kindOf(f: File): Kind {
    val e = f.extension.lowercase()
    return when {
        e in IMG -> Kind.IMAGE
        e in VID -> Kind.VIDEO
        e in AUD -> Kind.AUDIO
        e in TXT -> Kind.TEXT
        e == "pdf" -> Kind.PDF
        e in OFFICE_EXT -> Kind.OFFICE
        e in ARCHIVE_EXT -> Kind.ARCHIVE
        else -> Kind.OTHER
    }
}

/** Portapapeles interno para Copiar / Mover. */
object Clipboard {
    var file by mutableStateOf<File?>(null)
    var cut by mutableStateOf(false)
}

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = if (name.contains('.')) name.substringBeforeLast('.') else name
    val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
    var i = 1
    while (f.exists()) {
        f = File(dir, "$base ($i)$ext")
        i++
    }
    return f
}

fun pasteInto(dir: File): File {
    val src = Clipboard.file ?: error("No hay nada que pegar")
    if (!src.exists()) {
        Clipboard.file = null
        error("El archivo original ya no existe")
    }
    if (src.isDirectory && (dir.absolutePath + "/").startsWith(src.absolutePath + "/")) {
        error("No se puede pegar una carpeta dentro de sí misma")
    }
    val target = uniqueFile(dir, src.name)
    if (Clipboard.cut) {
        if (!src.renameTo(target)) {
            src.copyRecursively(target)
            src.deleteRecursively()
        }
        Clipboard.file = null
    } else {
        src.copyRecursively(target)
    }
    return target
}

private fun cleanName(name: String): String {
    val n = name.trim()
    require(n.isNotEmpty() && !n.contains('/')) { "Nombre no válido" }
    return n
}

fun renameFile(f: File, newName: String): File {
    val t = File(f.parentFile, cleanName(newName))
    require(!t.exists()) { "Ya existe un archivo con ese nombre" }
    if (!f.renameTo(t)) error("No se pudo renombrar")
    return t
}

fun createFolder(dir: File, name: String): File {
    val d = File(dir, cleanName(name))
    require(!d.exists()) { "Ya existe un archivo con ese nombre" }
    if (!d.mkdirs()) error("No se pudo crear la carpeta")
    return d
}

fun createTextFile(dir: File, name: String): File {
    var n = cleanName(name)
    if (!n.contains('.')) n += ".txt"
    val f = File(dir, n)
    require(!f.exists()) { "Ya existe un archivo con ese nombre" }
    if (!f.createNewFile()) error("No se pudo crear el archivo")
    return f
}
