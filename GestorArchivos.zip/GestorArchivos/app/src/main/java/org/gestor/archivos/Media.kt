package org.gestor.archivos

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaMetadata
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ------------------------------------------------------------ Visor de imágenes
fun decodeSampled(f: File, max: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.absolutePath, bounds)
    var s = 1
    while (bounds.outWidth / s > max || bounds.outHeight / s > max) s *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = s }
    val bmp = BitmapFactory.decodeFile(f.absolutePath, opts) ?: return null
    val rot = try {
        when (ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
    } catch (e: Exception) {
        0f
    }
    if (rot == 0f) return bmp
    val m = Matrix().apply { postRotate(rot) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

@Composable
fun ImageViewerScreen(files: List<File>, start: Int, onBack: () -> Unit) {
    val pager = rememberPagerState(initialPage = start, pageCount = { files.size })
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page -> ZoomableImage(files[page]) }
        Row(
            Modifier.fillMaxWidth().background(Color(0x99000000)).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←", color = Color.White, fontSize = 22.sp) }
            Text(
                files[pager.currentPage].name,
                color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text("${pager.currentPage + 1}/${files.size}", color = Color.White, modifier = Modifier.padding(end = 12.dp))
        }
    }
}

@Composable
fun ZoomableImage(f: File) {
    var bmp by remember(f) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(f) { mutableStateOf(false) }
    var scale by remember(f) { mutableFloatStateOf(1f) }
    var offset by remember(f) { mutableStateOf(Offset.Zero) }
    LaunchedEffect(f) {
        val b = withContext(Dispatchers.IO) { runCatching { decodeSampled(f, 2048) }.getOrNull() }
        bmp = b
        failed = b == null
    }
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(f) {
                detectTapGestures(onDoubleTap = {
                    scale = if (scale > 1f) 1f else 3f
                    offset = Offset.Zero
                })
            }
            .pointerInput(f) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        if (event.changes.size > 1 || scale > 1f) {
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale <= 1f) Offset.Zero else offset + pan
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = f.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer(
                    scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
                )
            )
        } else if (failed) {
            Text("No se puede mostrar esta imagen", color = Color.White)
        } else {
            CircularProgressIndicator()
        }
    }
}

// ------------------------------------------------------------ Reproductor de audio y vídeo
private fun fmt(ms: Long): String {
    val s = ms / 1000
    return String.format("%d:%02d", s / 60, s % 60)
}

@Composable
fun PlayerScreen(files: List<File>, start: Int, video: Boolean, onBack: () -> Unit, onExternal: (File) -> Unit) {
    if (video) {
        VideoHost(files, start, onBack, onExternal)
    } else {
        AudioHost(files, start, onBack, onExternal)
    }
}

/** Vídeo: reproductor propio de esta pantalla (se detiene al salir). */
@Composable
private fun VideoHost(files: List<File>, start: Int, onBack: () -> Unit, onExternal: (File) -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).setAudioAttributes(AudioAttributes.DEFAULT, true).build() }
    DisposableEffect(exo) {
        Music.controller?.pause()
        exo.setMediaItems(files.map { MediaItem.fromUri(Uri.fromFile(it)) }, start, 0L)
        exo.prepare()
        exo.playWhenReady = true
        onDispose { exo.release() }
    }
    PlayerUi(exo, true, files, onBack, onExternal)
}

/** Audio: se reproduce en el servicio, así sigue sonando en segundo plano. */
@Composable
private fun AudioHost(files: List<File>, start: Int, onBack: () -> Unit, onExternal: (File) -> Unit) {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf<Player?>(null) }
    var failed by remember { mutableStateOf(false) }
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(files, start) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        Music.connect(ctx, onFail = { failed = true }) { mc ->
            val items = files.map { f ->
                MediaItem.Builder()
                    .setUri(Uri.fromFile(f))
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(f.nameWithoutExtension).build())
                    .build()
            }
            mc.setMediaItems(items, start, 0L)
            mc.prepare()
            mc.play()
            ready = mc
        }
    }

    val p = ready
    if (p != null) {
        PlayerUi(p, false, files, onBack, onExternal)
    } else {
        BackHandler(onBack = onBack)
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            if (failed) {
                Text("No se pudo iniciar el reproductor de música.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onExternal(files[start]) }) { Text("Abrir con otra app") }
            } else {
                Text("Conectando…")
            }
        }
    }
}

@Composable
private fun PlayerUi(pl: Player, video: Boolean, files: List<File>, onBack: () -> Unit, onExternal: (File) -> Unit) {
    var index by remember(pl) { mutableIntStateOf(pl.currentMediaItemIndex.coerceAtLeast(0)) }
    var playing by remember(pl) { mutableStateOf(pl.isPlaying) }
    var pos by remember(pl) { mutableLongStateOf(0L) }
    var dur by remember(pl) { mutableLongStateOf(0L) }
    var error by remember(pl) { mutableStateOf<String?>(null) }
    var shuffle by remember(pl) { mutableStateOf(pl.shuffleModeEnabled) }
    var repeatMode by remember(pl) { mutableIntStateOf(pl.repeatMode) }
    var speedIdx by remember(pl) { mutableIntStateOf(1) }
    val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    DisposableEffect(pl) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                index = pl.currentMediaItemIndex.coerceAtLeast(0)
                error = null
            }

            override fun onPlayerError(e: PlaybackException) {
                error = "No se puede reproducir este formato (${e.errorCodeName})"
            }
        }
        pl.addListener(listener)
        onDispose { pl.removeListener(listener) }
    }
    LaunchedEffect(pl) {
        while (true) {
            pos = pl.currentPosition
            dur = pl.duration.coerceAtLeast(0L)
            delay(400)
        }
    }
    BackHandler(onBack = onBack)

    val white = Color.White
    val maxPos = dur.coerceAtLeast(1L).toFloat()
    val current = files.getOrNull(index) ?: files.first()

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", color = white, fontSize = 22.sp) }
            Text(current.name, color = white, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("${index + 1}/${files.size}", color = white, modifier = Modifier.padding(end = 12.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (video) {
                AndroidView(
                    factory = { c ->
                        PlayerView(c).apply {
                            useController = false
                            keepScreenOn = true
                            this.player = pl
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text("🎵", fontSize = 96.sp)
            }
            val err = error
            if (err != null) {
                Column(
                    Modifier.fillMaxWidth().background(Color(0xCC000000)).padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(err, color = white)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onExternal(current) }) { Text("Abrir con otra app") }
                }
            }
        }
        Slider(
            value = pos.toFloat().coerceIn(0f, maxPos),
            onValueChange = {
                pl.seekTo(it.toLong())
                pos = it.toLong()
            },
            valueRange = 0f..maxPos,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text(fmt(pos), color = white, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            Text(fmt(dur), color = white, style = MaterialTheme.typography.bodySmall)
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = {
                if (pl.hasPreviousMediaItem()) {
                    pl.seekToPreviousMediaItem()
                    pl.prepare()
                    pl.play()
                }
            }) { Text("⏮", color = white, fontSize = 24.sp) }
            TextButton(onClick = { pl.seekTo((pl.currentPosition - 10_000L).coerceAtLeast(0L)) }) {
                Text("−10", color = white, fontSize = 18.sp)
            }
            TextButton(onClick = {
                if (playing) {
                    pl.pause()
                } else {
                    if (pl.playbackState == Player.STATE_ENDED) pl.seekTo(0L)
                    pl.play()
                }
            }) { Text(if (playing) "⏸" else "▶️", color = white, fontSize = 32.sp) }
            TextButton(onClick = { pl.seekTo(pl.currentPosition + 10_000L) }) {
                Text("+10", color = white, fontSize = 18.sp)
            }
            TextButton(onClick = {
                if (pl.hasNextMediaItem()) {
                    pl.seekToNextMediaItem()
                    pl.prepare()
                    pl.play()
                }
            }) { Text("⏭", color = white, fontSize = 24.sp) }
        }
        Row(
            Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = {
                shuffle = !shuffle
                pl.shuffleModeEnabled = shuffle
            }) { Text(if (shuffle) "🔀 sí" else "🔀 no", color = white) }
            TextButton(onClick = {
                repeatMode = (repeatMode + 1) % 3
                pl.repeatMode = repeatMode
            }) {
                Text(
                    when (repeatMode) {
                        1 -> "🔂 una"
                        2 -> "🔁 todas"
                        else -> "🔁 no"
                    },
                    color = white
                )
            }
            TextButton(onClick = {
                speedIdx = (speedIdx + 1) % speeds.size
                pl.setPlaybackSpeed(speeds[speedIdx])
            }) { Text("${speeds[speedIdx]}x", color = white) }
        }
    }
}

// ------------------------------------------------------------ Editor de texto
@Composable
fun EditorScreen(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var loaded by remember(file) { mutableStateOf(false) }
    var tooBig by remember(file) { mutableStateOf(false) }
    var text by remember(file) { mutableStateOf("") }
    var saved by remember(file) { mutableStateOf("") }
    var confirmExit by remember { mutableStateOf(false) }

    LaunchedEffect(file) {
        val r = withContext(Dispatchers.IO) {
            runCatching { if (file.length() > 2_000_000L) null else file.readText() }
        }
        val t = r.getOrNull()
        if (t == null) {
            tooBig = true
        } else {
            text = t
            saved = t
        }
        loaded = true
    }

    val dirty = text != saved
    val exit: () -> Unit = {
        if (dirty) {
            confirmExit = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = exit)

    fun save(afterSave: () -> Unit) {
        scope.launch {
            val snapshot = text
            val r = withContext(Dispatchers.IO) { runCatching { file.writeText(snapshot) } }
            if (r.isSuccess) {
                saved = snapshot
                toast(ctx, "Guardado")
                afterSave()
            } else {
                toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header(file.name, exit) {
            TextButton(onClick = { save {} }, enabled = dirty) { Text("Guardar") }
        }
        if (!loaded) {
            Text("Cargando…", Modifier.padding(16.dp))
        } else if (tooBig) {
            Text("Este archivo es demasiado grande (más de 2 MB) o no se puede leer como texto.", Modifier.padding(16.dp))
        } else {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxSize().padding(8.dp),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp)
            )
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Hay cambios sin guardar") },
            text = { Text("¿Quieres guardarlos antes de salir?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmExit = false
                    save { onBack() }
                }) { Text("Guardar") }
            },
            dismissButton = {
                TextButton(onClick = {
                    confirmExit = false
                    onBack()
                }) { Text("Descartar") }
            }
        )
    }
}
