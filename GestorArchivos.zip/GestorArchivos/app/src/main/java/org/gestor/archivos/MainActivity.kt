package org.gestor.archivos

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val DATE_FMT = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
private val DATETIME_FMT = SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault())

class MainActivity : ComponentActivity() {

    private var access by mutableStateOf(false)

    private val legacyPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        access = hasAccess()
    }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContent {
            val dark = when (Prefs.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.systemBarsPadding()) { App(access, ::requestAccess) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        access = hasAccess()
        if (access) Thread { runCatching { TrashManager.purgeOlderThan(Prefs.trashDays) } }.start()
    }
}

sealed interface Screen {
    data object Home : Screen
    data object Trash : Screen
    data object Config : Screen
    data class Browser(val root: File, val dir: File) : Screen
    data class Category(val cat: Cat) : Screen
}

@Composable
fun App(access: Boolean, onRequest: () -> Unit) {
    if (!access) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Necesito acceso a todos los archivos para poder gestionarlos.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequest) { Text("Conceder acceso") }
        }
        return
    }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    when (val s = screen) {
        Screen.Home -> HomeScreen(
            onBrowse = { root -> screen = Screen.Browser(root, root) },
            onCategory = { cat -> screen = Screen.Category(cat) },
            onTrash = { screen = Screen.Trash },
            onSettings = { screen = Screen.Config }
        )
        Screen.Trash -> TrashScreen(onBack = { screen = Screen.Home })
        Screen.Config -> SettingsScreen(onBack = { screen = Screen.Home })
        is Screen.Browser -> BrowserScreen(s.root, s.dir, onOpen = { d -> screen = Screen.Browser(s.root, d) }, onExit = { screen = Screen.Home })
        is Screen.Category -> CategoryScreen(s.cat, onBack = { screen = Screen.Home })
    }
}

// ------------------------------------------------------------ Componentes comunes
@Composable
fun Header(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
        } else {
            Spacer(Modifier.width(12.dp))
        }
        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        actions()
    }
}

// ------------------------------------------------------------ Inicio
@Composable
fun HomeScreen(onBrowse: (File) -> Unit, onCategory: (Cat) -> Unit, onTrash: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val cats = remember { categories() }
    var stats by remember { mutableStateOf<Map<String, Pair<Long, Int>>>(emptyMap()) }
    LaunchedEffect(Unit) {
        stats = withContext(Dispatchers.IO) {
            cats.associate { c -> c.id to (runCatching { catStats(ctx, c) }.getOrNull() ?: (0L to 0)) }
        }
    }
    val internal = remember { internalRoot() }
    val sd = remember { sdRoot(ctx) }
    val trashCount = remember { runCatching { TrashManager.list().size }.getOrDefault(0) }

    LazyColumn {
        item {
            Header("Gestor de Archivos", null) {
                TextButton(onClick = onSettings) { Text("⚙️", fontSize = 22.sp) }
            }
        }
        item { StorageCard("💾  Almacenamiento interno", internal) { onBrowse(internal) } }
        if (sd != null) {
            item { StorageCard("💳  Tarjeta SD", sd) { onBrowse(sd) } }
        }
        item { Spacer(Modifier.height(8.dp)) }
        items(cats, key = { it.id }) { c ->
            val st = stats[c.id]
            val sub = if (st == null) "…" else "${formatSize(st.first)} (${st.second})"
            BigRow(c.emoji, c.label, sub) { onCategory(c) }
        }
        item { BigRow("🗑️", "Papelera", "$trashCount elementos") { onTrash() } }
    }
}

@Composable
fun StorageCard(title: String, root: File, onClick: () -> Unit) {
    val space = remember(root) { spaceOf(root) }
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (space != null) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { space.fraction }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text(
                    "${formatSize(space.used)} / ${formatSize(space.total)}  ·  ${space.percent}% utilizado",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun BigRow(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 26.sp, modifier = Modifier.padding(end = 16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ------------------------------------------------------------ Categoría (lista plana)
@Composable
fun CategoryScreen(cat: Cat, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf<List<File>?>(null) }
    LaunchedEffect(refresh) {
        files = withContext(Dispatchers.IO) { runCatching { catFiles(ctx, cat) }.getOrDefault(emptyList()) }
    }
    BackHandler(onBack = onBack)
    val list = files
    Column {
        Header("${cat.emoji} ${cat.label}", onBack)
        if (list == null) {
            Text("Cargando…", Modifier.padding(16.dp))
        } else if (list.isEmpty()) {
            Text("No hay archivos en esta categoría", Modifier.padding(16.dp))
        } else {
            FileList(list, onOpenDir = {}, onChanged = { refresh++ }, showParent = true)
        }
    }
}

// ------------------------------------------------------------ Explorador de carpetas
@Composable
fun BrowserScreen(root: File, dir: File, onOpen: (File) -> Unit, onExit: () -> Unit) {
    var refresh by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val space = remember(root, refresh) { spaceOf(root) }
    val files = remember(dir, refresh, query, Prefs.showHidden, Prefs.sort) {
        val cmp: Comparator<File> = when (Prefs.sort) {
            1 -> compareByDescending<File> { it.isDirectory }.thenByDescending { it.lastModified() }
            2 -> compareByDescending<File> { it.isDirectory }.thenByDescending { if (it.isDirectory) 0L else it.length() }
            else -> compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        }
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { (Prefs.showHidden || !it.name.startsWith(".")) && (query.isBlank() || it.name.contains(query, ignoreCase = true)) }
            .sortedWith(cmp)
    }
    val goBack: () -> Unit = { if (dir == root) onExit() else onOpen(dir.parentFile ?: root) }
    BackHandler(onBack = goBack)

    val title = if (dir == root) {
        if (root == internalRoot()) "Almacenamiento interno" else "Tarjeta SD"
    } else dir.name

    Column {
        Header(title, goBack) {
            if (space != null) {
                Surface(shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                    Text("${space.percent}% UTILIZADO", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
            TextButton(onClick = { searching = !searching; if (!searching) query = "" }) { Text("🔍", fontSize = 18.sp) }
            Box {
                TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 22.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf("Ordenar por nombre", "Ordenar por fecha", "Ordenar por tamaño").forEachIndexed { i, t ->
                        DropdownMenuItem(
                            text = { Text((if (Prefs.sort == i) "✓ " else "") + t) },
                            onClick = { Prefs.putSort(i); menu = false }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (Prefs.showHidden) "Ocultar archivos ocultos" else "Mostrar archivos ocultos") },
                        onClick = { Prefs.putShowHidden(!Prefs.showHidden); menu = false }
                    )
                }
            }
        }
        if (searching) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Buscar en esta carpeta") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
        if (files.isEmpty()) Text(if (query.isBlank()) "Carpeta vacía" else "Sin resultados", Modifier.padding(16.dp))
        FileList(files, onOpenDir = onOpen, onChanged = { refresh++ })
    }
}

@Composable
fun FileList(files: List<File>, onOpenDir: (File) -> Unit, onChanged: () -> Unit, showParent: Boolean = false) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var toDelete by remember { mutableStateOf<File?>(null) }

    fun perform(f: File) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { removeFile(f) } }
            val msg = if (r.isSuccess) (if (Prefs.useTrash) "Movido a la papelera" else "Eliminado") else "Error: ${r.exceptionOrNull()?.message}"
            toast(ctx, msg)
            onChanged()
        }
    }

    LazyColumn {
        items(files, key = { it.absolutePath }) { f ->
            FileRow(
                f, showParent,
                onClick = { if (f.isDirectory) onOpenDir(f) else openFile(ctx, f) },
                onDelete = { if (Prefs.useTrash && !Prefs.confirmDelete) perform(f) else toDelete = f },
                onExtract = {
                    scope.launch {
                        toast(ctx, "Extrayendo…")
                        val r = withContext(Dispatchers.IO) {
                            runCatching { ArchiveExtractor.extract(f, File(f.parentFile, stripExt(f.name))) }
                        }
                        toast(ctx, if (r.isSuccess) "Extraído" else "Error: ${r.exceptionOrNull()?.message}")
                        onChanged()
                    }
                }
            )
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(if (Prefs.useTrash) "¿Mover a la papelera?" else "¿Eliminar definitivamente?") },
            text = { Text(if (Prefs.useTrash) f.name else "${f.name}\n\nEsta acción no se puede deshacer.") },
            confirmButton = { TextButton(onClick = { toDelete = null; perform(f) }) { Text(if (Prefs.useTrash) "Mover" else "Eliminar") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun FileRow(f: File, showParent: Boolean, onClick: () -> Unit, onDelete: () -> Unit, onExtract: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val isArchive = ArchiveExtractor.isSupported(f)
    val sub = remember(f, Prefs.sizeUnit) {
        if (f.isDirectory) {
            val n = f.list()?.size ?: 0
            if (n == 1) "1 elemento" else "$n elementos"
        } else {
            formatSize(f.length()) + (if (showParent) "  ·  ${f.parentFile?.name ?: ""}" else "")
        }
    }
    val date = remember(f) { DATE_FMT.format(Date(f.lastModified())) }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (f.isDirectory) "📁" else if (isArchive) "🗜️" else "📄", fontSize = 26.sp, modifier = Modifier.padding(end = 12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 20.sp) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (isArchive) DropdownMenuItem(text = { Text("Extraer aquí") }, onClick = { menu = false; onExtract() })
                DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

// ------------------------------------------------------------ Papelera
@Composable
fun TrashScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    val entries = remember(refresh) { TrashManager.list() }
    BackHandler(onBack = onBack)

    fun doIt(block: () -> Unit) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching(block) }
            if (r.isFailure) toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
            refresh++
        }
    }

    Column {
        Header("Papelera", onBack) {
            TextButton(onClick = { doIt { TrashManager.empty() } }, enabled = entries.isNotEmpty()) { Text("Vaciar") }
        }
        Text("Se vacía sola a los ${Prefs.trashDays} días", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
        if (entries.isEmpty()) Text("La papelera está vacía", Modifier.padding(16.dp))
        LazyColumn {
            items(entries, key = { it.id }) { e ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                    Text("${e.originalPath}\n${DATETIME_FMT.format(Date(e.deletedAt))}", style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = { doIt { TrashManager.restore(e) } }) { Text("Restaurar") }
                        TextButton(onClick = { doIt { TrashManager.deleteForever(e) } }) { Text("Eliminar definitivamente") }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------ Ajustes
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val days = listOf(7, 30, 90)
    LazyColumn {
        item { Header("Ajustes", onBack) }

        item { SectionTitle("Apariencia") }
        item { ChoiceRow("Tema", listOf("Según el sistema", "Claro", "Oscuro"), Prefs.theme) { Prefs.putTheme(it) } }

        item { SectionTitle("Configuración de la papelera de reciclaje") }
        item { SwitchRow("Utilizar la papelera de reciclaje", "Los archivos eliminados se pueden restaurar", Prefs.useTrash) { Prefs.putUseTrash(it) } }
        item { SwitchRow("Mostrar confirmación de reciclaje", "Preguntar antes de eliminar", Prefs.confirmDelete) { Prefs.putConfirmDelete(it) } }
        item {
            ChoiceRow("Vaciar la papelera automáticamente", days.map { "$it días" }, days.indexOf(Prefs.trashDays).coerceAtLeast(0)) {
                Prefs.putTrashDays(days[it])
            }
        }

        item { SectionTitle("Configuración avanzada") }
        item { SwitchRow("Mostrar archivos ocultos", "Los que empiezan por punto (.)", Prefs.showHidden) { Prefs.putShowHidden(it) } }
        item { ChoiceRow("Unidad de tamaño de archivo", listOf("Automática", "GB", "MB"), Prefs.sizeUnit) { Prefs.putSizeUnit(it) } }
        item { ChoiceRow("Ordenar archivos por", listOf("Nombre", "Fecha", "Tamaño"), Prefs.sort) { Prefs.putSort(it) } }

        item { SectionTitle("Información") }
        item {
            Text(
                "Gestor de Archivos 0.2.0\nCódigo abierto · Sin anuncios · Sin rastreo",
                Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(start = 16.dp, top = 20.dp, end = 16.dp, bottom = 4.dp))
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
fun ChoiceRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clickable { open = true }.padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(options.getOrElse(selected) { "" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title) },
            text = {
                Column {
                    options.forEachIndexed { i, o ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onSelect(i); open = false }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = i == selected, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(o)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Cerrar") } }
        )
    }
}

// ------------------------------------------------------------ Utilidades
private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

private fun openFile(ctx: Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(i, f.name)) }.onFailure { toast(ctx, "No hay app para abrir este archivo") }
}
