package org.gestor.archivos

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {

    private var access by mutableStateOf(false)

    private val legacyPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        access = hasAccess()
    }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize().systemBarsPadding()) { App(access, ::requestAccess) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        access = hasAccess()
        if (access) Thread { runCatching { TrashManager.purgeOlderThan(30) } }.start()
    }
}

sealed interface Screen {
    data object Home : Screen
    data object Trash : Screen
    data class Browser(val root: File, val dir: File) : Screen
}

@Composable
fun App(access: Boolean, onRequest: () -> Unit) {
    if (!access) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Necesito acceso a todos los archivos para poder gestionarlos.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequest) { Text("Conceder acceso") }
        }
        return
    }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    when (val s = screen) {
        Screen.Home -> HomeScreen(onOpen = { screen = Screen.Browser(it, it) }, onTrash = { screen = Screen.Trash })
        Screen.Trash -> TrashScreen(onBack = { screen = Screen.Home })
        is Screen.Browser -> BrowserScreen(s.root, s.dir, onOpen = { screen = Screen.Browser(s.root, it) }, onExit = { screen = Screen.Home })
    }
}

@Composable
fun HomeScreen(onOpen: (File) -> Unit, onTrash: () -> Unit) {
    val ctx = LocalContext.current
    fun pub(d: String) = Environment.getExternalStoragePublicDirectory(d)
    val sd = ctx.getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
        ?.absolutePath?.substringBefore("/Android")?.let(::File)
    val cats = buildList {
        add("💾  Almacenamiento interno" to Environment.getExternalStorageDirectory())
        sd?.let { add("💳  Tarjeta SD" to it) }
        add("⬇️  Descargas" to pub(Environment.DIRECTORY_DOWNLOADS))
        add("🖼️  Imágenes" to pub(Environment.DIRECTORY_PICTURES))
        add("🎵  Audio" to pub(Environment.DIRECTORY_MUSIC))
        add("🎬  Vídeos" to pub(Environment.DIRECTORY_MOVIES))
        add("📄  Documentos" to pub(Environment.DIRECTORY_DOCUMENTS))
    }
    LazyColumn {
        item { Text("Gestor de Archivos", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp)) }
        items(cats) { (label, file) ->
            Text(label, Modifier.fillMaxWidth().clickable { file.mkdirs(); onOpen(file) }.padding(16.dp))
        }
        item { Text("🗑️  Papelera", Modifier.fillMaxWidth().clickable(onClick = onTrash).padding(16.dp)) }
    }
}

@Composable
fun BrowserScreen(root: File, dir: File, onOpen: (File) -> Unit, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<File?>(null) }
    val files = remember(dir, refresh) {
        (dir.listFiles()?.toList() ?: emptyList())
            .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    BackHandler { if (dir == root) onExit() else onOpen(dir.parentFile ?: root) }

    Column {
        Text(dir.absolutePath, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(12.dp))
        if (files.isEmpty()) Text("Carpeta vacía", Modifier.padding(16.dp))
        LazyColumn {
            items(files, key = { it.absolutePath }) { f ->
                FileRow(
                    f,
                    onClick = { if (f.isDirectory) onOpen(f) else openFile(ctx, f) },
                    onDelete = { toDelete = f },
                    onExtract = {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                runCatching { ArchiveExtractor.extract(f, File(dir, f.nameWithoutExtension)) }
                            }
                            toast(ctx, if (r.isSuccess) "Extraído" else "Error: ${r.exceptionOrNull()?.message}")
                            refresh++
                        }
                    }
                )
            }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Mover a la papelera?") },
            text = { Text(f.name) },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { runCatching { TrashManager.moveToTrash(f) } }
                        toast(ctx, if (r.isSuccess) "Movido a la papelera" else "Error: ${r.exceptionOrNull()?.message}")
                        refresh++
                    }
                }) { Text("Mover") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun FileRow(f: File, onClick: () -> Unit, onDelete: () -> Unit, onExtract: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val isArchive = ArchiveExtractor.isSupported(f)
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (f.isDirectory) "📁" else if (isArchive) "🗜️" else "📄", Modifier.padding(end = 12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1)
            Text(if (f.isDirectory) "Carpeta" else humanSize(f.length()), style = MaterialTheme.typography.bodySmall)
        }
        Box {
            TextButton(onClick = { menu = true }) { Text("⋮") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (isArchive) DropdownMenuItem(text = { Text("Extraer aquí") }, onClick = { menu = false; onExtract() })
                DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
fun TrashScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    val items = remember(refresh) { TrashManager.list() }
    val df = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    BackHandler(onBack = onBack)

    fun run(block: () -> Unit) = scope.launch {
        val r = withContext(Dispatchers.IO) { runCatching(block) }
        if (r.isFailure) toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
        refresh++
    }

    Column {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Papelera (se vacía sola a los 30 días)", Modifier.weight(1f))
            TextButton(onClick = { run { TrashManager.empty() } }, enabled = items.isNotEmpty()) { Text("Vaciar") }
        }
        if (items.isEmpty()) Text("La papelera está vacía", Modifier.padding(16.dp))
        LazyColumn {
            items(items, key = { it.id }) { e ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(e.name, maxLines = 1)
                    Text("${e.originalPath}\n${df.format(Date(e.deletedAt))}", style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = { run { TrashManager.restore(e) } }) { Text("Restaurar") }
                        TextButton(onClick = { run { TrashManager.deleteForever(e) } }) { Text("Eliminar definitivamente") }
                    }
                }
            }
        }
    }
}

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

private fun humanSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

private fun openFile(ctx: Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(i, f.name)) }.onFailure { toast(ctx, "No hay app para abrir este archivo") }
}
