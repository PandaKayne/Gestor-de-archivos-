package org.gestor.archivos

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val DATE_FMT = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
private val DATETIME_FMT = SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault())

class MainActivity : ComponentActivity() {

    private var access by mutableStateOf(false)
    private var volumeTick by mutableIntStateOf(0)

    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            volumeTick++
            val msg = when (i.action) {
                Intent.ACTION_MEDIA_MOUNTED -> "Almacenamiento externo conectado"
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> "Dispositivo USB conectado"
                Intent.ACTION_MEDIA_UNMOUNTED,
                Intent.ACTION_MEDIA_REMOVED,
                Intent.ACTION_MEDIA_EJECT,
                Intent.ACTION_MEDIA_BAD_REMOVAL,
                UsbManager.ACTION_USB_DEVICE_DETACHED -> "Almacenamiento o dispositivo USB desconectado"
                else -> null
            }
            if (msg != null) Toast.makeText(c, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private val legacyPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        access = hasAccess()
    }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        PDFBoxResourceLoader.init(applicationContext)
        val mediaFilter = IntentFilter().apply {
            addAction(Intent.ACTION_MEDIA_MOUNTED)
            addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_REMOVED)
            addAction(Intent.ACTION_MEDIA_EJECT)
            addAction(Intent.ACTION_MEDIA_BAD_REMOVAL)
            addDataScheme("file")
        }
        ContextCompat.registerReceiver(this, volumeReceiver, mediaFilter, ContextCompat.RECEIVER_EXPORTED)
        val usbFilter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, volumeReceiver, usbFilter, ContextCompat.RECEIVER_EXPORTED)
        setContent {
            val dark = when (Prefs.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            MaterialTheme(colorScheme = appColors(dark, Prefs.accent)) {
                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.systemBarsPadding()) { App(access, volumeTick, ::requestAccess) }
                }
            }
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(volumeReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        access = hasAccess()
        volumeTick++
        if (access) Thread { runCatching { TrashManager.purgeOlderThan(Prefs.trashDays) } }.start()
    }
}

sealed interface Screen {
    data object Home : Screen
    data object Trash : Screen
    data object Config : Screen
    data class Browser(val root: File, val dir: File) : Screen
    data class Category(val cat: Cat) : Screen
    data class Image(val files: List<File>, val index: Int) : Screen
    data class Player(val files: List<File>, val index: Int, val video: Boolean) : Screen
    data class Editor(val file: File) : Screen
    data class Pdf(val file: File) : Screen
    data class Office(val file: File) : Screen
    data class PdfPages(val file: File) : Screen
    data class PdfForm(val file: File) : Screen
    data class Archive(val file: File) : Screen
}

/** Decide qué pantalla interna abre un archivo (o null si hay que abrirlo con otra app). */
fun routeFile(f: File): Screen? {
    val kind = kindOf(f)
    if (kind == Kind.OTHER) return null
    val siblings = (f.parentFile?.listFiles()?.toList() ?: listOf(f))
        .filter { it.isFile && kindOf(it) == kind }
        .sortedBy { it.name.lowercase() }
    val idx = siblings.indexOf(f).coerceAtLeast(0)
    return when (kind) {
        Kind.IMAGE -> Screen.Image(siblings, idx)
        Kind.VIDEO -> Screen.Player(siblings, idx, true)
        Kind.AUDIO -> Screen.Player(siblings, idx, false)
        Kind.TEXT -> Screen.Editor(f)
        Kind.PDF -> Screen.Pdf(f)
        Kind.OFFICE -> Screen.Office(f)
        Kind.ARCHIVE -> Screen.Archive(f)
        else -> null
    }
}

@Composable
fun App(access: Boolean, volumeTick: Int, onRequest: () -> Unit) {
    if (!access) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Necesito acceso a todos los archivos para poder gestionarlos.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequest) { Text("Conceder acceso") }
        }
        return
    }
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var back by remember { mutableStateOf<Screen>(Screen.Home) }

    val openFile: (File) -> Unit = { f ->
        val target = routeFile(f)
        if (target != null) {
            back = screen
            screen = target
        } else {
            openExternal(ctx, f)
        }
    }

    val openScreen: (Screen) -> Unit = { t ->
        back = screen
        screen = t
    }

    Column(Modifier.fillMaxSize()) {
    Box(Modifier.weight(1f)) {
    when (val s = screen) {
        Screen.Home -> HomeScreen(
            onBrowse = { root -> screen = Screen.Browser(root, root) },
            onCategory = { cat -> screen = Screen.Category(cat) },
            onTrash = { screen = Screen.Trash },
            onSettings = { screen = Screen.Config },
            volumeTick = volumeTick
        )
        Screen.Trash -> TrashScreen(onBack = { screen = Screen.Home })
        Screen.Config -> SettingsScreen(onBack = { screen = Screen.Home })
        is Screen.Browser -> BrowserScreen(
            s.root, s.dir,
            onOpen = { d -> screen = Screen.Browser(s.root, d) },
            onOpenFile = openFile,
            onScreen = openScreen,
            volumeTick = volumeTick,
            onExit = { screen = Screen.Home }
        )
        is Screen.Category -> CategoryScreen(s.cat, onOpenFile = openFile, onScreen = openScreen, onBack = { screen = Screen.Home })
        is Screen.Image -> ImageViewerScreen(s.files, s.index, onBack = { screen = back })
        is Screen.Player -> PlayerScreen(
            s.files, s.index, s.video,
            onBack = { screen = back },
            onExternal = { f -> openExternal(ctx, f) }
        )
        is Screen.Editor -> EditorScreen(s.file, onBack = { screen = back })
        is Screen.Pdf -> PdfViewerScreen(
            s.file,
            onBack = { screen = back },
            onExternal = { f -> openExternal(ctx, f) },
            onOpenPdf = { f -> screen = Screen.Pdf(f) }
        )
        is Screen.Office -> OfficeViewerScreen(s.file, onBack = { screen = back }, onExternal = { f -> openExternal(ctx, f) })
        is Screen.PdfPages -> PdfPagesScreen(s.file, onBack = { screen = back })
        is Screen.PdfForm -> PdfFormScreen(s.file, onBack = { screen = back })
        is Screen.Archive -> ArchiveViewerScreen(s.file, onBack = { screen = back })
    }
    }
    val cur = screen
    if (!(cur is Screen.Player && !cur.video)) MiniPlayer()
    }
}

// ------------------------------------------------------------ Componentes comunes
@Composable
fun Header(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
        } else {
            Spacer(Modifier.width(12.dp))
        }
        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun NameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(v) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ------------------------------------------------------------ Inicio
@Composable
fun HomeScreen(onBrowse: (File) -> Unit, onCategory: (Cat) -> Unit, onTrash: () -> Unit, onSettings: () -> Unit, volumeTick: Int) {
    val ctx = LocalContext.current
    val cats = remember { categories() }
    var stats by remember { mutableStateOf<Map<String, Pair<Long, Int>>>(emptyMap()) }
    LaunchedEffect(volumeTick) {
        stats = withContext(Dispatchers.IO) {
            cats.associate { c -> c.id to (runCatching { catStats(ctx, c) }.getOrNull() ?: (0L to 0)) }
        }
    }
    val internal = remember { internalRoot() }
    val vols = remember(volumeTick) { volumes(ctx) }
    val trashCount = remember { runCatching { TrashManager.list().size }.getOrDefault(0) }

    LazyColumn {
        item {
            Header("Gestor de Archivos", null) {
                TextButton(onClick = onSettings) { Text("⚙️", fontSize = 22.sp) }
            }
        }
        item { StorageCard("💾  Almacenamiento interno", internal, volumeTick) { onBrowse(internal) } }
        items(vols, key = { it.root.path }) { v ->
            StorageCard((if (v.usb) "🔌  " else "💳  ") + v.label, v.root, volumeTick) { onBrowse(v.root) }
        }
        item { Spacer(Modifier.height(8.dp)) }
        items(cats, key = { it.id }) { c ->
            val st = stats[c.id]
            val sub = if (st == null) "…" else "${formatSize(st.first)} (${st.second})"
            BigRow(c.emoji, c.label, sub) { onCategory(c) }
        }
        item { BigRow("🗑️", "Papelera", "$trashCount elementos") { onTrash() } }
    }
}

@Composable
fun StorageCard(title: String, root: File, tick: Int = 0, onClick: () -> Unit) {
    val space = remember(root, tick) { spaceOf(root) }
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (space != null) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { space.fraction }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text(
                    "${formatSize(space.used)} / ${formatSize(space.total)}  ·  ${space.percent}% utilizado",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun BigRow(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 26.sp, modifier = Modifier.padding(end = 16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ------------------------------------------------------------ Categoría (lista plana)
@Composable
fun CategoryScreen(cat: Cat, onOpenFile: (File) -> Unit, onScreen: (Screen) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf<List<File>?>(null) }
    LaunchedEffect(refresh) {
        files = withContext(Dispatchers.IO) { runCatching { catFiles(ctx, cat) }.getOrDefault(emptyList()) }
    }
    BackHandler(onBack = onBack)
    val list = files
    Column {
        Header("${cat.emoji} ${cat.label}", onBack)
        if (list == null) {
            Text("Cargando…", Modifier.padding(16.dp))
        } else if (list.isEmpty()) {
            Text("No hay archivos en esta categoría", Modifier.padding(16.dp))
        } else {
            FileList(list, onOpenDir = {}, onOpenFile = onOpenFile, onScreen = onScreen, onChanged = { refresh++ }, showParent = true)
        }
    }
}

// ------------------------------------------------------------ Explorador de carpetas
@Composable
fun BrowserScreen(
    root: File, dir: File, onOpen: (File) -> Unit, onOpenFile: (File) -> Unit,
    onScreen: (Screen) -> Unit, volumeTick: Int, onExit: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var newDialog by remember { mutableIntStateOf(0) }
    val space = remember(root, refresh, volumeTick) { spaceOf(root) }
    val files = remember(dir, refresh, volumeTick, query, Prefs.showHidden, Prefs.sort) {
        val cmp: Comparator<File> = when (Prefs.sort) {
            1 -> compareByDescending<File> { it.isDirectory }.thenByDescending { it.lastModified() }
            2 -> compareByDescending<File> { it.isDirectory }.thenByDescending { if (it.isDirectory) 0L else it.length() }
            else -> compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        }
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { (Prefs.showHidden || !it.name.startsWith(".")) && (query.isBlank() || it.name.contains(query, ignoreCase = true)) }
            .sortedWith(cmp)
    }
    val goBack: () -> Unit = { if (dir == root) onExit() else onOpen(dir.parentFile ?: root) }
    BackHandler(onBack = goBack)
    LaunchedEffect(volumeTick) {
        if (root != internalRoot() && !root.exists()) onExit()
    }

    val title = if (dir == root) rootLabel(ctx, root) else dir.name

    Column {
        Header(title, goBack) {
            if (space != null) {
                Surface(shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                    Text("${space.percent}% UTILIZADO", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
            TextButton(onClick = { searching = !searching; if (!searching) query = "" }) { Text("🔍", fontSize = 18.sp) }
            Box {
                TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 22.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("📁 Nueva carpeta") }, onClick = { menu = false; newDialog = 1 })
                    DropdownMenuItem(text = { Text("📝 Nuevo archivo de texto") }, onClick = { menu = false; newDialog = 2 })
                    DropdownMenuItem(
                        text = { Text("📕 PDF con las imágenes de esta carpeta") },
                        onClick = {
                            menu = false
                            runTool(ctx, scope, "Creando PDF…", { refresh++ }) {
                                val imgs = (dir.listFiles()?.toList() ?: emptyList())
                                    .filter { it.isFile && kindOf(it) == Kind.IMAGE }
                                    .sortedBy { it.name.lowercase() }
                                if (imgs.isEmpty()) error("No hay imágenes en esta carpeta")
                                val out = uniqueFile(dir, dir.name + " (imágenes).pdf")
                                PdfEdit.imagesToPdf(imgs, out)
                                "Creado: ${out.name}"
                            }
                        }
                    )
                    val clip = Clipboard.file
                    if (clip != null) {
                        DropdownMenuItem(
                            text = { Text("📋 Pegar «${clip.name}»") },
                            onClick = {
                                menu = false
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { runCatching { pasteInto(dir) } }
                                    toast(ctx, if (r.isSuccess) "Listo" else "Error: ${r.exceptionOrNull()?.message}")
                                    refresh++
                                }
                            }
                        )
                    }
                    listOf("Ordenar por nombre", "Ordenar por fecha", "Ordenar por tamaño").forEachIndexed { i, t ->
                        DropdownMenuItem(
                            text = { Text((if (Prefs.sort == i) "✓ " else "") + t) },
                            onClick = { Prefs.putSort(i); menu = false }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (Prefs.showHidden) "Ocultar archivos ocultos" else "Mostrar archivos ocultos") },
                        onClick = { Prefs.putShowHidden(!Prefs.showHidden); menu = false }
                    )
                }
            }
        }
        if (searching) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Buscar en esta carpeta") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
        if (files.isEmpty()) Text(if (query.isBlank()) "Carpeta vacía" else "Sin resultados", Modifier.padding(16.dp))
        FileList(files, onOpenDir = onOpen, onOpenFile = onOpenFile, onScreen = onScreen, onChanged = { refresh++ })
    }

    if (newDialog != 0) {
        val isFolder = newDialog == 1
        NameDialog(
            title = if (isFolder) "Nueva carpeta" else "Nuevo archivo de texto",
            initial = if (isFolder) "Nueva carpeta" else "nuevo.txt",
            confirm = "Crear",
            onConfirm = { n ->
                newDialog = 0
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        runCatching { if (isFolder) createFolder(dir, n) else createTextFile(dir, n) }
                    }
                    if (r.isSuccess) {
                        refresh++
                        if (!isFolder) onOpenFile(r.getOrThrow())
                    } else {
                        toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
                    }
                }
            },
            onDismiss = { newDialog = 0 }
        )
    }
}

@Composable
fun FileList(
    files: List<File>, onOpenDir: (File) -> Unit, onOpenFile: (File) -> Unit,
    onScreen: (Screen) -> Unit, onChanged: () -> Unit, showParent: Boolean = false
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var toDelete by remember { mutableStateOf<File?>(null) }
    var toRename by remember { mutableStateOf<File?>(null) }
    var mergeBase by remember { mutableStateOf<File?>(null) }

    fun perform(f: File) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { removeFile(f) } }
            val msg = if (r.isSuccess) (if (Prefs.useTrash) "Movido a la papelera" else "Eliminado") else "Error: ${r.exceptionOrNull()?.message}"
            toast(ctx, msg)
            onChanged()
        }
    }

    fun extract(f: File) {
        scope.launch {
            toast(ctx, "Extrayendo…")
            val r = withContext(Dispatchers.IO) {
                runCatching { ArchiveExtractor.extract(f, File(f.parentFile, stripExt(f.name))) }
            }
            toast(ctx, if (r.isSuccess) "Extraído" else "Error: ${r.exceptionOrNull()?.message}")
            onChanged()
        }
    }

    LazyColumn {
        items(files, key = { it.absolutePath }) { f ->
            FileRow(
                f, showParent,
                onClick = { if (f.isDirectory) onOpenDir(f) else onOpenFile(f) },
                onAction = { action ->
                    when (action) {
                        "delete" -> {
                            if (Prefs.useTrash && !Prefs.confirmDelete) perform(f) else toDelete = f
                        }
                        "extract" -> extract(f)
                        "copy" -> {
                            Clipboard.file = f
                            Clipboard.cut = false
                            toast(ctx, "Copiado. Abre la carpeta destino y elige Pegar (menú ⋮)")
                        }
                        "cut" -> {
                            Clipboard.file = f
                            Clipboard.cut = true
                            toast(ctx, "Listo para mover. Abre la carpeta destino y elige Pegar (menú ⋮)")
                        }
                        "rename" -> toRename = f
                        "external" -> openExternal(ctx, f)
                        "pdf_pages" -> onScreen(Screen.PdfPages(f))
                        "pdf_form" -> onScreen(Screen.PdfForm(f))
                        "pdf_merge" -> mergeBase = f
                        "pdf_split" -> runTool(ctx, scope, "Dividiendo PDF…", onChanged) {
                            val n = PdfEdit.splitAll(f, uniqueFile(f.parentFile!!, f.nameWithoutExtension + " (páginas)"))
                            "Listo: $n páginas en una carpeta nueva"
                        }
                        "img_pdf" -> runTool(ctx, scope, "Creando PDF…", onChanged) {
                            val out = uniqueFile(f.parentFile!!, f.nameWithoutExtension + ".pdf")
                            PdfEdit.imagesToPdf(listOf(f), out)
                            "Creado: ${out.name}"
                        }
                    }
                }
            )
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(if (Prefs.useTrash) "¿Mover a la papelera?" else "¿Eliminar definitivamente?") },
            text = {
                Column {
                    val k = kindOf(f)
                    if (!f.isDirectory && (k == Kind.IMAGE || k == Kind.VIDEO || k == Kind.AUDIO)) {
                        FileThumb(f, k, "📄", 120.dp)
                        Spacer(Modifier.height(12.dp))
                    }
                    Text(if (Prefs.useTrash) f.name else "${f.name}\n\nEsta acción no se puede deshacer.")
                }
            },
            confirmButton = { TextButton(onClick = { toDelete = null; perform(f) }) { Text(if (Prefs.useTrash) "Mover" else "Eliminar") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }

    toRename?.let { f ->
        NameDialog(
            title = "Renombrar",
            initial = f.name,
            confirm = "Renombrar",
            onConfirm = { n ->
                toRename = null
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { renameFile(f, n) } }
                    if (r.isFailure) toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
                    onChanged()
                }
            },
            onDismiss = { toRename = null }
        )
    }

    mergeBase?.let { base ->
        MergeDialog(base, onDismiss = { mergeBase = null }) { chosen ->
            mergeBase = null
            runTool(ctx, scope, "Uniendo PDF…", onChanged) {
                val out = uniqueFile(base.parentFile!!, base.nameWithoutExtension + " (unido).pdf")
                PdfEdit.merge(chosen, out)
                "Creado: ${out.name}"
            }
        }
    }
}

@Composable
fun FileRow(f: File, showParent: Boolean, onClick: () -> Unit, onAction: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val isArchive = ArchiveExtractor.isSupported(f)
    val icon = if (f.isDirectory) "📁" else when (kindOf(f)) {
        Kind.IMAGE -> "🖼️"
        Kind.VIDEO -> "🎬"
        Kind.AUDIO -> "🎵"
        Kind.TEXT -> "📝"
        Kind.PDF -> "📕"
        Kind.ARCHIVE -> "🗜️"
        Kind.OFFICE -> when (f.extension.lowercase()) {
            "xlsx" -> "📗"
            "pptx" -> "📙"
            else -> "📘"
        }
        else -> if (isArchive) "🗜️" else "📄"
    }
    val sub = remember(f, Prefs.sizeUnit) {
        if (f.isDirectory) {
            val n = f.list()?.size ?: 0
            if (n == 1) "1 elemento" else "$n elementos"
        } else {
            formatSize(f.length()) + (if (showParent) "  ·  ${f.parentFile?.name ?: ""}" else "")
        }
    }
    val date = remember(f) { DATE_FMT.format(Date(f.lastModified())) }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        val k = kindOf(f)
        if (!f.isDirectory && (k == Kind.IMAGE || k == Kind.VIDEO || k == Kind.AUDIO)) {
            Box(Modifier.padding(end = 12.dp)) { FileThumb(f, k, icon) }
        } else {
            Text(icon, fontSize = 26.sp, modifier = Modifier.padding(end = 12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 20.sp) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (isArchive) DropdownMenuItem(text = { Text("Extraer aquí") }, onClick = { menu = false; onAction("extract") })
                if (!f.isDirectory) DropdownMenuItem(text = { Text("Abrir con otra app") }, onClick = { menu = false; onAction("external") })
                if (kindOf(f) == Kind.PDF) {
                    DropdownMenuItem(text = { Text("Editar páginas…") }, onClick = { menu = false; onAction("pdf_pages") })
                    DropdownMenuItem(text = { Text("Rellenar formulario") }, onClick = { menu = false; onAction("pdf_form") })
                    DropdownMenuItem(text = { Text("Unir con otros PDF…") }, onClick = { menu = false; onAction("pdf_merge") })
                    DropdownMenuItem(text = { Text("Dividir en páginas sueltas") }, onClick = { menu = false; onAction("pdf_split") })
                }
                if (kindOf(f) == Kind.IMAGE) {
                    DropdownMenuItem(text = { Text("Convertir a PDF") }, onClick = { menu = false; onAction("img_pdf") })
                }
                DropdownMenuItem(text = { Text("Copiar") }, onClick = { menu = false; onAction("copy") })
                DropdownMenuItem(text = { Text("Mover") }, onClick = { menu = false; onAction("cut") })
                DropdownMenuItem(text = { Text("Renombrar") }, onClick = { menu = false; onAction("rename") })
                DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onAction("delete") })
            }
        }
    }
}

// ------------------------------------------------------------ Papelera
@Composable
fun TrashScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    val entries = remember(refresh) { TrashManager.list() }
    BackHandler(onBack = onBack)

    fun doIt(block: () -> Unit) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching(block) }
            if (r.isFailure) toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
            refresh++
        }
    }

    Column {
        Header("Papelera", onBack) {
            TextButton(onClick = { doIt { TrashManager.empty() } }, enabled = entries.isNotEmpty()) { Text("Vaciar") }
        }
        Text("Se vacía sola a los ${Prefs.trashDays} días", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
        if (entries.isEmpty()) Text("La papelera está vacía", Modifier.padding(16.dp))
        LazyColumn {
            items(entries, key = { it.id }) { e ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
                    val k = kindOf(File(e.name))
                    if (k == Kind.IMAGE || k == Kind.VIDEO || k == Kind.AUDIO) {
                        Box(Modifier.padding(end = 12.dp)) { FileThumb(TrashManager.fileOf(e), k, "📄", 72.dp) }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                        Text("${e.originalPath}\n${DATETIME_FMT.format(Date(e.deletedAt))}", style = MaterialTheme.typography.bodySmall)
                        Row {
                            TextButton(onClick = { doIt { TrashManager.restore(e) } }) { Text("Restaurar") }
                            TextButton(onClick = { doIt { TrashManager.deleteForever(e) } }) { Text("Eliminar") }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------ Ajustes
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val days = listOf(7, 30, 90)
    LazyColumn {
        item { Header("Ajustes", onBack) }

        item { SectionTitle("Apariencia") }
        item { ChoiceRow("Modo", listOf("Según el sistema", "Claro", "Oscuro"), Prefs.theme) { Prefs.putTheme(it) } }
        item { ChoiceRow("Color del tema", listOf("Predeterminado", "Azul", "Gris", "Rojo", "Verde"), Prefs.accent) { Prefs.putAccent(it) } }

        item { SectionTitle("Configuración de la papelera de reciclaje") }
        item { SwitchRow("Utilizar la papelera de reciclaje", "Los archivos eliminados se pueden restaurar", Prefs.useTrash) { Prefs.putUseTrash(it) } }
        item { SwitchRow("Mostrar confirmación de reciclaje", "Preguntar antes de eliminar", Prefs.confirmDelete) { Prefs.putConfirmDelete(it) } }
        item {
            ChoiceRow("Vaciar la papelera automáticamente", days.map { "$it días" }, days.indexOf(Prefs.trashDays).coerceAtLeast(0)) {
                Prefs.putTrashDays(days[it])
            }
        }

        item { SectionTitle("Configuración avanzada") }
        item { SwitchRow("Mostrar archivos ocultos", "Los que empiezan por punto (.)", Prefs.showHidden) { Prefs.putShowHidden(it) } }
        item { ChoiceRow("Unidad de tamaño de archivo", listOf("Automática", "GB", "MB"), Prefs.sizeUnit) { Prefs.putSizeUnit(it) } }
        item { ChoiceRow("Ordenar archivos por", listOf("Nombre", "Fecha", "Tamaño"), Prefs.sort) { Prefs.putSort(it) } }

        item { SectionTitle("Información") }
        item {
            Text(
                "Gestor de Archivos 0.6.2\nCódigo abierto · Sin anuncios · Sin rastreo",
                Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(start = 16.dp, top = 20.dp, end = 16.dp, bottom = 4.dp))
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
fun ChoiceRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clickable { open = true }.padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(options.getOrElse(selected) { "" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title) },
            text = {
                Column {
                    options.forEachIndexed { i, o ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onSelect(i); open = false }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = i == selected, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(o)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Cerrar") } }
        )
    }
}

// ------------------------------------------------------------ Utilidades
fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

fun openExternal(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: Exception) {
        toast(ctx, "No hay app para abrir este archivo")
    }
}

private fun runTool(ctx: Context, scope: CoroutineScope, working: String, onDone: () -> Unit, block: () -> String) {
    scope.launch {
        toast(ctx, working)
        val r = withContext(Dispatchers.IO) { runCatching(block) }
        toast(ctx, r.getOrElse { e -> "Error: ${e.message}" })
        onDone()
    }
}

@Composable
fun MergeDialog(base: File, onDismiss: () -> Unit, onConfirm: (List<File>) -> Unit) {
    val others = remember(base) {
        (base.parentFile?.listFiles()?.toList() ?: emptyList())
            .filter { it.isFile && it.extension.equals("pdf", ignoreCase = true) && it != base }
            .sortedBy { it.name.lowercase() }
    }
    val picked = remember(base) { mutableStateListOf<File>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unir «${base.name}» con…") },
        text = {
            if (others.isEmpty()) {
                Text("No hay otros PDF en esta carpeta.")
            } else {
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(others) { f ->
                        Row(
                            Modifier.fillMaxWidth().clickable { if (f in picked) picked.remove(f) else picked.add(f) }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = f in picked, onCheckedChange = null)
                            Spacer(Modifier.width(8.dp))
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = picked.isNotEmpty(), onClick = { onConfirm(listOf(base) + picked.toList()) }) { Text("Unir") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
