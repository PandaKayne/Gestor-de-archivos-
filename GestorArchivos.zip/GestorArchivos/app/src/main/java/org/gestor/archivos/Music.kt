package org.gestor.archivos

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken

/** Servicio que mantiene la música sonando con la pantalla apagada o fuera de la app. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, exo).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}

/** Control de la música desde la app (se conecta al servicio). */
object Music {
    var controller: MediaController? by mutableStateOf(null)
        private set
    var title by mutableStateOf("")
        private set
    var playing by mutableStateOf(false)
        private set
    var active by mutableStateOf(false)
        private set

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh()
        }
    }

    private fun refresh() {
        val c = controller
        if (c == null) {
            active = false
            playing = false
            return
        }
        active = c.mediaItemCount > 0
        playing = c.isPlaying
        title = c.mediaMetadata.title?.toString() ?: ""
    }

    fun connect(ctx: Context, onFail: () -> Unit, then: (MediaController) -> Unit) {
        val existing = controller
        if (existing != null) {
            then(existing)
            return
        }
        val app = ctx.applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val mc = future.get()
                mc.addListener(listener)
                controller = mc
                refresh()
                then(mc)
            } catch (e: Exception) {
                onFail()
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun stop() {
        val c = controller ?: return
        c.stop()
        c.clearMediaItems()
        refresh()
    }
}

/** Barra sencilla de música que aparece abajo mientras suena algo. */
@Composable
fun MiniPlayer() {
    if (!Music.active) return
    val c = Music.controller ?: return
    Surface(tonalElevation = 3.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🎵 ${Music.title}", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            TextButton(onClick = { if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem() }) { Text("⏮") }
            TextButton(onClick = { if (c.isPlaying) c.pause() else c.play() }) { Text(if (Music.playing) "⏸" else "▶️") }
            TextButton(onClick = { if (c.hasNextMediaItem()) c.seekToNextMediaItem() }) { Text("⏭") }
            TextButton(onClick = { Music.stop() }) { Text("✕") }
        }
    }
}
