package org.gestor.archivos

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Xml
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.util.Collections
import java.util.zip.ZipFile

// ------------------------------------------------------------ PDF (PdfRenderer de Android)
class PdfDoc(file: File) {
    private val fd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try {
        PdfRenderer(fd)
    } catch (e: Exception) {
        fd.close()
        throw e
    }

    val pageCount: Int get() = renderer.pageCount

    @Synchronized
    fun render(index: Int, widthPx: Int): Bitmap {
        val page = renderer.openPage(index)
        try {
            val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            page.close()
        }
    }

    @Synchronized
    fun close() {
        try { renderer.close() } catch (e: Exception) { }
        try { fd.close() } catch (e: Exception) { }
    }
}

private val PALETTE = listOf(0xFFFFEB3B.toInt(), 0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF000000.toInt(), 0xFF43A047.toInt())
private val YELLOW = PALETTE[0]
private val BLACK = PALETTE[3]
private val TEXT_SIZES = listOf(0.02f, 0.03f, 0.045f)

@Composable
fun ToolChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        modifier = Modifier.padding(2.dp).clickable(onClick = onClick)
    ) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 20.sp)
    }
}

@Composable
fun PdfViewerScreen(file: File, onBack: () -> Unit, onExternal: (File) -> Unit, onOpenPdf: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val doc = remember(file) { runCatching { PdfDoc(file) } }
    DisposableEffect(file) { onDispose { doc.getOrNull()?.close() } }
    var zoomIdx by remember { mutableIntStateOf(0) }
    val zooms = listOf(1f, 1.5f, 2f)
    val listState = rememberLazyListState()
    val d = doc.getOrNull()

    var edit by remember { mutableStateOf(false) }
    var tool by remember { mutableStateOf(Tool.MOVE) }
    var color by remember { mutableIntStateOf(BLACK) }
    var sizeIdx by remember { mutableIntStateOf(1) }
    var saving by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var pendingText by remember { mutableStateOf<Pair<Int, Offset>?>(null) }
    val edits = remember(file) { HashMap<Int, SnapshotStateList<Annot>>() }
    val history = remember(file) { mutableStateListOf<Int>() }
    val dirty = history.isNotEmpty()

    val exit: () -> Unit = {
        if (dirty) {
            confirmExit = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = exit)

    fun pick(t: Tool) {
        tool = t
        if (t == Tool.HL && color == BLACK) color = YELLOW
        if (t != Tool.HL && color == YELLOW) color = BLACK
    }

    fun undo() {
        if (history.isNotEmpty()) {
            val p = history.removeAt(history.lastIndex)
            val l = edits[p]
            if (l != null && l.isNotEmpty()) l.removeAt(l.lastIndex)
        }
    }

    fun save() {
        val snapshot = edits.mapValues { it.value.toList() }
        scope.launch {
            saving = true
            val out = uniqueFile(file.parentFile!!, file.nameWithoutExtension + " (editado).pdf")
            val r = withContext(Dispatchers.IO) { runCatching { PdfEdit.annotate(file, out, snapshot) } }
            saving = false
            if (r.isSuccess) {
                toast(ctx, "Guardado: ${out.name}")
                onOpenPdf(out)
            } else {
                toast(ctx, "Error: ${r.exceptionOrNull()?.message}")
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header(file.name, exit) {
            if (d != null) {
                Text("${listState.firstVisibleItemIndex + 1}/${d.pageCount}", style = MaterialTheme.typography.labelMedium)
                TextButton(onClick = { if (zoomIdx > 0) zoomIdx-- }) { Text("−", fontSize = 22.sp) }
                TextButton(onClick = { if (zoomIdx < zooms.size - 1) zoomIdx++ }) { Text("+", fontSize = 22.sp) }
                TextButton(onClick = {
                    edit = !edit
                    tool = if (edit) Tool.PEN else Tool.MOVE
                    if (edit && color == YELLOW) color = BLACK
                }) { Text(if (edit) "✔" else "✏️", fontSize = 20.sp) }
            }
        }
        if (edit && d != null) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ToolChip("✋", tool == Tool.MOVE) { pick(Tool.MOVE) }
                ToolChip("✏️", tool == Tool.PEN) { pick(Tool.PEN) }
                ToolChip("🖍️", tool == Tool.HL) { pick(Tool.HL) }
                ToolChip("🔤", tool == Tool.TEXT) { pick(Tool.TEXT) }
                for (c in PALETTE) {
                    Box(
                        Modifier.padding(4.dp).size(26.dp)
                            .background(Color(c), CircleShape)
                            .border(if (c == color) 3.dp else 1.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                            .clickable { color = c }
                    )
                }
                TextButton(onClick = { sizeIdx = (sizeIdx + 1) % TEXT_SIZES.size }) { Text("Aa ${sizeIdx + 1}") }
                TextButton(onClick = { undo() }, enabled = dirty) { Text("↩", fontSize = 20.sp) }
                Button(onClick = { save() }, enabled = dirty && !saving) { Text(if (saving) "Guardando…" else "💾 Guardar copia") }
            }
        }
        if (d == null) {
            Column(Modifier.padding(16.dp)) {
                Text("No se puede abrir este PDF (puede estar protegido con contraseña o dañado).")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onExternal(file) }) { Text("Abrir con otra app") }
            }
        } else {
            val density = LocalDensity.current
            val screenDp = LocalConfiguration.current.screenWidthDp.dp
            val zoom = zooms[zoomIdx]
            val widthPx = with(density) { (screenDp * zoom).roundToPx() }
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .background(Color.DarkGray)
                    .horizontalScroll(rememberScrollState())
            ) {
                LazyColumn(state = listState, modifier = Modifier.width(screenDp * zoom)) {
                    items(d.pageCount) { i ->
                        val annots = edits.getOrPut(i) { mutableStateListOf<Annot>() }
                        PdfPage(
                            d, i, widthPx, annots,
                            if (edit) tool else Tool.MOVE, color,
                            onInk = { ink ->
                                annots.add(ink)
                                history.add(i)
                            },
                            onTap = { o -> pendingText = i to o }
                        )
                    }
                }
            }
        }
    }

    pendingText?.let { (pi, pos) ->
        NameDialog(
            title = "Escribir texto",
            initial = "",
            confirm = "Añadir",
            onConfirm = { t ->
                if (t.isNotBlank()) {
                    edits.getOrPut(pi) { mutableStateListOf<Annot>() }.add(TextNote(pos.x, pos.y, t, color, TEXT_SIZES[sizeIdx]))
                    history.add(pi)
                }
                pendingText = null
            },
            onDismiss = { pendingText = null }
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Hay cambios sin guardar") },
            text = { Text("Las anotaciones se guardan en una copia nueva del PDF.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmExit = false
                    save()
                }) { Text("Guardar copia") }
            },
            dismissButton = {
                TextButton(onClick = {
                    confirmExit = false
                    onBack()
                }) { Text("Salir sin guardar") }
            }
        )
    }
}

@Composable
fun PdfPage(
    doc: PdfDoc, index: Int, widthPx: Int,
    annots: SnapshotStateList<Annot>, tool: Tool, color: Int,
    onInk: (Ink) -> Unit, onTap: (Offset) -> Unit
) {
    var bmp by remember(index, widthPx) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(index, widthPx) {
        bmp = withContext(Dispatchers.IO) { runCatching { doc.render(index, widthPx) }.getOrNull() }
    }
    val b = bmp
    if (b != null) {
        Box(Modifier.fillMaxWidth()) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Página ${index + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth()
            )
            PageOverlay(annots, tool, color, onInk, onTap, Modifier.matchParentSize())
        }
    } else {
        Box(Modifier.fillMaxWidth().height(400.dp).background(Color.White), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
fun PageOverlay(
    annots: SnapshotStateList<Annot>, tool: Tool, color: Int,
    onInk: (Ink) -> Unit, onTap: (Offset) -> Unit, modifier: Modifier
) {
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val inkCb by rememberUpdatedState(onInk)
    val tapCb by rememberUpdatedState(onTap)
    val widthNorm = if (tool == Tool.HL) 0.03f else 0.003f
    val gesture: Modifier = when (tool) {
        Tool.PEN, Tool.HL -> Modifier.pointerInput(tool, color) {
            detectDragGestures(
                onDragStart = { o -> cur = listOf(Offset(o.x / size.width, o.y / size.width)) },
                onDrag = { change, _ ->
                    change.consume()
                    cur = cur + Offset(change.position.x / size.width, change.position.y / size.width)
                },
                onDragEnd = {
                    if (cur.isNotEmpty()) inkCb(Ink(cur, color, widthNorm, tool == Tool.HL))
                    cur = emptyList()
                },
                onDragCancel = { cur = emptyList() }
            )
        }
        Tool.TEXT -> Modifier.pointerInput(tool) {
            detectTapGestures { o -> tapCb(Offset(o.x / size.width, o.y / size.width)) }
        }
        Tool.MOVE -> Modifier
    }
    Canvas(modifier.then(gesture)) {
        val wpx = size.width
        fun drawOneInk(i: Ink) {
            if (i.pts.isEmpty()) return
            val path = Path()
            path.moveTo(i.pts[0].x * wpx, i.pts[0].y * wpx)
            for (k in 1 until i.pts.size) path.lineTo(i.pts[k].x * wpx, i.pts[k].y * wpx)
            if (i.pts.size == 1) path.lineTo(i.pts[0].x * wpx + 0.1f, i.pts[0].y * wpx)
            drawPath(
                path,
                Color(i.argb).copy(alpha = if (i.hl) 0.35f else 1f),
                style = Stroke(width = i.w * wpx, cap = if (i.hl) StrokeCap.Butt else StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        for (a in annots) {
            when (a) {
                is Ink -> drawOneInk(a)
                is TextNote -> drawIntoCanvas { c ->
                    val paint = android.graphics.Paint().apply {
                        isAntiAlias = true
                        this.color = a.argb
                        textSize = a.size * wpx
                    }
                    a.text.split('\n').forEachIndexed { i, line ->
                        c.nativeCanvas.drawText(line, a.x * wpx, (a.y + a.size * 0.8f + i * a.size * 1.2f) * wpx, paint)
                    }
                }
            }
        }
        if (cur.isNotEmpty()) drawOneInk(Ink(cur, color, widthNorm, tool == Tool.HL))
    }
}

// ------------------------------------------------------------ Office (.docx .xlsx .pptx): texto
object OfficeText {

    fun read(f: File): String = when (f.extension.lowercase()) {
        "docx" -> docx(f)
        "pptx" -> pptx(f)
        "xlsx" -> xlsx(f)
        "odt", "ods", "odp" -> odf(f)
        "epub" -> epub(f)
        else -> error("Formato no soportado")
    }

    private const val MAX_CHARS = 2_000_000

    private fun parser(zip: ZipFile, name: String): XmlPullParser? {
        val e = zip.getEntry(name) ?: return null
        val p = Xml.newPullParser()
        p.setInput(zip.getInputStream(e), "UTF-8")
        return p
    }

    private fun numbered(zip: ZipFile, prefix: String): List<String> =
        Collections.list(zip.entries())
            .map { it.name }
            .filter { it.startsWith(prefix) && it.endsWith(".xml") }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0 }

    private fun docx(f: File): String = ZipFile(f).use { zip ->
        val p = parser(zip, "word/document.xml") ?: error("No es un documento de Word válido")
        val sb = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && sb.length < MAX_CHARS) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "w:t" -> sb.append(p.nextText())
                    "w:tab" -> sb.append('\t')
                    "w:br" -> sb.append('\n')
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "w:p") {
                sb.append('\n')
            }
            ev = p.next()
        }
        sb.toString()
    }

    private fun pptx(f: File): String = ZipFile(f).use { zip ->
        val sb = StringBuilder()
        numbered(zip, "ppt/slides/slide").forEachIndexed { i, name ->
            sb.append("—— Diapositiva ${i + 1} ——\n")
            val p = parser(zip, name)
            if (p != null) {
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT && sb.length < MAX_CHARS) {
                    if (ev == XmlPullParser.START_TAG && p.name == "a:t") {
                        sb.append(p.nextText())
                    } else if (ev == XmlPullParser.END_TAG && p.name == "a:p") {
                        sb.append('\n')
                    }
                    ev = p.next()
                }
            }
            sb.append('\n')
        }
        if (sb.isEmpty()) error("No se encontraron diapositivas")
        sb.toString()
    }

    private fun odf(f: File): String = ZipFile(f).use { zip ->
        val p = parser(zip, "content.xml") ?: error("Documento ODF no válido")
        val ods = f.extension.equals("ods", ignoreCase = true)
        val sb = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && sb.length < MAX_CHARS) {
            if (ev == XmlPullParser.TEXT) {
                sb.append(p.text)
            } else if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "text:tab" -> sb.append('\t')
                    "text:line-break" -> sb.append('\n')
                    "text:s" -> sb.append(' ')
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "text:p", "text:h" -> if (!ods) sb.append('\n')
                    "table:table-cell" -> if (ods) sb.append("  |  ")
                    "table:table-row" -> if (ods) sb.append('\n')
                    "draw:page" -> sb.append('\n')
                }
            }
            ev = p.next()
        }
        sb.toString()
    }

    private fun htmlToText(h: String): String = h
        .replace(Regex("(?s)<(script|style)[^>]*>.*?</\\1>"), "")
        .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>|</tr>"), "\n")
        .replace(Regex("<[^>]+>"), "")
        .replace("&nbsp;", " ")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&amp;", "&")
        .replace(Regex("\n{3,}"), "\n\n")

    private fun epub(f: File): String = ZipFile(f).use { zip ->
        val names = Collections.list(zip.entries())
            .map { it.name }
            .filter {
                val l = it.lowercase()
                l.endsWith(".xhtml") || l.endsWith(".html") || l.endsWith(".htm")
            }
            .sorted()
        val sb = StringBuilder()
        for (n in names) {
            if (sb.length > MAX_CHARS) break
            val entry = zip.getEntry(n) ?: continue
            val raw = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            sb.append(htmlToText(raw)).append("\n\n")
        }
        if (sb.isBlank()) error("No se encontró texto en el libro")
        sb.toString()
    }

    private fun colIndex(ref: String?): Int {
        if (ref == null) return -1
        var n = 0
        for (c in ref) {
            if (c in 'A'..'Z') n = n * 26 + (c - 'A' + 1) else break
        }
        return n - 1
    }

    private fun xlsx(f: File): String = ZipFile(f).use { zip ->
        val shared = ArrayList<String>()
        val sp = parser(zip, "xl/sharedStrings.xml")
        if (sp != null) {
            var cur: StringBuilder? = null
            var ev = sp.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    if (sp.name == "si") {
                        cur = StringBuilder()
                    } else if (sp.name == "t") {
                        cur?.append(sp.nextText())
                    }
                } else if (ev == XmlPullParser.END_TAG && sp.name == "si") {
                    shared.add(cur?.toString() ?: "")
                    cur = null
                }
                ev = sp.next()
            }
        }
        val sb = StringBuilder()
        numbered(zip, "xl/worksheets/sheet").forEachIndexed { i, name ->
            sb.append("—— Hoja ${i + 1} ——\n")
            val p = parser(zip, name)
            if (p != null) {
                val row = ArrayList<String>()
                var cellType: String? = null
                var cellRef: String? = null
                var value: String? = null
                var rows = 0
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT && sb.length < MAX_CHARS && rows < 20000) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "c" -> {
                                cellType = p.getAttributeValue(null, "t")
                                cellRef = p.getAttributeValue(null, "r")
                                value = null
                            }
                            "v" -> value = p.nextText()
                            "t" -> value = (value ?: "") + p.nextText()
                        }
                    } else if (ev == XmlPullParser.END_TAG) {
                        if (p.name == "c") {
                            val txt = if (cellType == "s") {
                                shared.getOrNull(value?.toIntOrNull() ?: -1) ?: ""
                            } else {
                                value ?: ""
                            }
                            val col = colIndex(cellRef)
                            while (col > 0 && row.size < col) row.add("")
                            row.add(txt)
                        } else if (p.name == "row") {
                            sb.append(row.joinToString("  |  ")).append('\n')
                            row.clear()
                            rows++
                        }
                    }
                    ev = p.next()
                }
            }
            sb.append('\n')
        }
        if (sb.isEmpty()) error("No se encontraron hojas")
        sb.toString()
    }
}

@Composable
fun OfficeViewerScreen(file: File, onBack: () -> Unit, onExternal: (File) -> Unit) {
    var lines by remember(file) { mutableStateOf<List<String>?>(null) }
    var err by remember(file) { mutableStateOf<String?>(null) }
    LaunchedEffect(file) {
        val r = withContext(Dispatchers.IO) { runCatching { OfficeText.read(file) } }
        if (r.isSuccess) {
            lines = r.getOrThrow().lines().take(30000)
        } else {
            err = r.exceptionOrNull()?.message ?: "Error desconocido"
        }
    }
    BackHandler(onBack = onBack)
    val mono = file.extension.lowercase() == "xlsx" || file.extension.lowercase() == "ods"
    val l = lines
    val e = err

    Column(Modifier.fillMaxSize()) {
        Header(file.name, onBack) {
            TextButton(onClick = { onExternal(file) }) { Text("Abrir con…") }
        }
        Text(
            "Vista de solo texto. Para ver el diseño original usa «Abrir con…».",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (e != null) {
            Text("No se pudo leer el archivo: $e", Modifier.padding(16.dp))
        } else if (l == null) {
            Text("Cargando…", Modifier.padding(16.dp))
        } else {
            SelectionContainer {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    items(l) { line ->
                        Text(
                            line,
                            style = if (mono) TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                            else MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
