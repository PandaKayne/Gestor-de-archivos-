package org.gestor.archivos

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.junrar.Archive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.File
import java.io.InputStream
import java.util.Collections
import java.util.zip.ZipFile

/** Lista el contenido de un archivo comprimido sin extraerlo. */
object ArchiveList {
    data class Entry(val name: String, val size: Long, val dir: Boolean)

    fun list(f: File): List<Entry> {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".zip") -> ZipFile(f).use { z ->
                Collections.list(z.entries()).map { Entry(it.name, it.size, it.isDirectory) }
            }
            n.endsWith(".rar") -> Archive(f).use { a ->
                a.fileHeaders.map { Entry(it.fileName, it.fullUnpackSize, it.isDirectory) }
            }
            n.endsWith(".7z") -> {
                val out = ArrayList<Entry>()
                SevenZFile(f).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        out.add(Entry(e.name, e.size, e.isDirectory))
                        e = z.nextEntry
                    }
                }
                out
            }
            n.endsWith(".tar") -> tarEntries(f.inputStream().buffered())
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> tarEntries(GzipCompressorInputStream(f.inputStream().buffered()))
            else -> error("Este tipo de archivo no se puede explorar")
        }
    }

    private fun tarEntries(input: InputStream): List<Entry> {
        val out = ArrayList<Entry>()
        TarArchiveInputStream(input).use { t ->
            var e = t.nextTarEntry
            while (e != null) {
                out.add(Entry(e.name, e.size, e.isDirectory))
                e = t.nextTarEntry
            }
        }
        return out
    }
}

@Composable
fun ArchiveViewerScreen(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var entries by remember(file) { mutableStateOf<List<ArchiveList.Entry>?>(null) }
    var failure by remember(file) { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(file) {
        val r = withContext(Dispatchers.IO) { runCatching { ArchiveList.list(file) } }
        if (r.isSuccess) {
            entries = r.getOrThrow().take(5000)
        } else {
            val e = r.exceptionOrNull()
            failure = if (e != null && e.javaClass.simpleName.contains("V5")) {
                "Este RAR es de versión 5 (RAR5) y todavía no está soportado"
            } else {
                e?.message ?: "Error desconocido"
            }
        }
    }
    BackHandler(onBack = onBack)
    val list = entries
    val fail = failure

    Column(Modifier.fillMaxSize()) {
        Header(file.name, onBack) {
            TextButton(
                enabled = !busy && fail == null,
                onClick = {
                    scope.launch {
                        busy = true
                        toast(ctx, "Extrayendo…")
                        val r = withContext(Dispatchers.IO) {
                            runCatching { ArchiveExtractor.extract(file, File(file.parentFile, stripExt(file.name))) }
                        }
                        busy = false
                        toast(ctx, if (r.isSuccess) "Extraído en una carpeta junto al archivo" else "Error: ${r.exceptionOrNull()?.message}")
                    }
                }
            ) { Text(if (busy) "Extrayendo…" else "Extraer aquí") }
        }
        if (fail != null) {
            Text("No se pudo leer el contenido: $fail", Modifier.padding(16.dp))
        } else if (list == null) {
            Text("Cargando…", Modifier.padding(16.dp))
        } else {
            Text("${list.size} elementos", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(list) { e ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (e.dir) "📁" else "📄", fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp))
                        Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (!e.dir) Text(formatSize(e.size), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
