package org.gestor.archivos

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Miniaturas de imágenes, vídeos (un fotograma) y música (carátula incrustada).
 * Caché limitada en memoria y máximo 3 miniaturas generándose a la vez, para no frenar el móvil.
 */
object Thumbs {
    private const val MAX_PX = 256
    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val failed = LruCache<String, Boolean>(500)
    private val gate = Semaphore(3)

    fun cached(key: String): Bitmap? = cache.get(key)

    suspend fun load(key: String, f: File, kind: Kind): Bitmap? {
        cache.get(key)?.let { return it }
        if (failed.get(key) == true) return null
        val bmp = gate.withPermit {
            withContext(Dispatchers.IO) { runCatching { make(f, kind) }.getOrNull() }
        }
        if (bmp != null) cache.put(key, bmp) else failed.put(key, true)
        return bmp
    }

    private fun make(f: File, kind: Kind): Bitmap? = when (kind) {
        Kind.IMAGE -> decodeSampled(f, MAX_PX)
        Kind.VIDEO -> withRetriever(f) { r ->
            val frame = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0L)
            frame?.let { shrink(it) }
        }
        Kind.AUDIO -> withRetriever(f) { r ->
            r.embeddedPicture?.let { bytes ->
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, b)
                var s = 1
                while (b.outWidth / s > MAX_PX || b.outHeight / s > MAX_PX) s *= 2
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            }
        }
        else -> null
    }

    private fun shrink(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= MAX_PX) return b
        val k = MAX_PX.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }

    private fun withRetriever(f: File, block: (MediaMetadataRetriever) -> Bitmap?): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            block(r)
        } finally {
            runCatching { r.release() }
        }
    }
}

/** Cuadro con la miniatura; si no hay (o mientras carga) muestra el emoji de siempre. */
@Composable
fun FileThumb(f: File, kind: Kind, fallback: String, size: Dp = 48.dp) {
    val key = f.absolutePath + "|" + f.lastModified() + "|" + f.length()
    var bmp by remember(key) { mutableStateOf(Thumbs.cached(key)) }
    LaunchedEffect(key) {
        if (bmp == null) bmp = Thumbs.load(key, f, kind)
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            val img = remember(b) { b.asImageBitmap() }
            Image(img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(size))
            if (kind == Kind.VIDEO) {
                Text("▶", fontSize = (size.value / 3).sp, color = androidx.compose.ui.graphics.Color.White)
            }
        } else {
            Text(fallback, fontSize = (size.value / 2).sp)
        }
    }
}
