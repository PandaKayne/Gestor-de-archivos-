package org.gestor.archivos

import com.github.junrar.Junrar
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Extrae ZIP, RAR, 7Z, TAR, TAR.GZ/TGZ y GZ. Protegido contra "zip slip". */
object ArchiveExtractor {

    private val exts = setOf("zip", "rar", "7z", "tar", "gz", "tgz")

    fun isSupported(f: File) = f.isFile && f.extension.lowercase() in exts

    fun extract(file: File, dest: File) {
        dest.mkdirs()
        val name = file.name.lowercase()
        when {
            name.endsWith(".zip") -> zip(file, dest)
            name.endsWith(".rar") -> try {
                Junrar.extract(file, dest)
            } catch (e: Exception) {
                if (e.javaClass.simpleName.contains("V5") || (e.message ?: "").contains("v5", ignoreCase = true)) {
                    error("Este RAR es de versión 5 (RAR5) y todavía no está soportado")
                } else {
                    throw e
                }
            }
            name.endsWith(".7z") -> sevenZ(file, dest)
            name.endsWith(".tar") -> tar(file.inputStream().buffered(), dest)
            name.endsWith(".tar.gz") || name.endsWith(".tgz") ->
                tar(GzipCompressorInputStream(file.inputStream().buffered()), dest)
            name.endsWith(".gz") -> GzipCompressorInputStream(file.inputStream().buffered()).use { gz ->
                File(dest, file.nameWithoutExtension).outputStream().use { gz.copyTo(it) }
            }
            else -> error("Formato no soportado")
        }
    }

    private fun safe(dest: File, entryName: String): File {
        val out = File(dest, entryName)
        require(out.canonicalPath.startsWith(dest.canonicalPath + File.separator)) { "Ruta no válida en el archivo" }
        return out
    }

    private fun write(input: InputStream, out: File) {
        out.parentFile?.mkdirs()
        out.outputStream().use { input.copyTo(it) }
    }

    private fun zip(file: File, dest: File) {
        ZipInputStream(file.inputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val out = safe(dest, e.name)
                if (e.isDirectory) out.mkdirs() else write(zis, out)
                e = zis.nextEntry
            }
        }
    }

    private fun tar(input: InputStream, dest: File) {
        TarArchiveInputStream(input).use { t ->
            var e = t.nextTarEntry
            while (e != null) {
                val out = safe(dest, e.name)
                if (e.isDirectory) out.mkdirs() else write(t, out)
                e = t.nextTarEntry
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun sevenZ(file: File, dest: File) {
        SevenZFile(file).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val out = safe(dest, e.name)
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { os ->
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = z.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n)
                        }
                    }
                }
                e = z.nextEntry
            }
        }
    }
}
