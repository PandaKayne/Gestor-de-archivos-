package org.gestor.archivos

import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Papelera propia: mueve a .GestorTrash y guarda la ruta original para restaurar. */
object TrashManager {

    data class Entry(val id: String, val originalPath: String, val name: String, val deletedAt: Long)

    private val dir: File
        get() = File(Environment.getExternalStorageDirectory(), ".GestorTrash").also { it.mkdirs() }
    private val index get() = File(dir, "index.json")

    @Synchronized
    fun list(): List<Entry> {
        if (!index.exists()) return emptyList()
        val arr = JSONArray(index.readText())
        return List(arr.length()) { i ->
            arr.getJSONObject(i).let { Entry(it.getString("id"), it.getString("path"), it.getString("name"), it.getLong("at")) }
        }.sortedByDescending { it.deletedAt }
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("path", it.originalPath).put("name", it.name).put("at", it.deletedAt)) }
        index.writeText(arr.toString())
    }

    private fun move(src: File, dst: File) {
        if (src.renameTo(dst)) return
        // Entre volúmenes (p. ej. tarjeta SD) renameTo falla: copiar y borrar.
        src.copyRecursively(dst, overwrite = true)
        if (!src.deleteRecursively()) {
            dst.deleteRecursively()
            error("No se pudo mover ${src.name}")
        }
    }

    @Synchronized
    fun moveToTrash(f: File) {
        val id = UUID.randomUUID().toString()
        move(f, File(dir, id))
        save(list() + Entry(id, f.absolutePath, f.name, System.currentTimeMillis()))
    }

    @Synchronized
    fun restore(e: Entry) {
        var target = File(e.originalPath)
        if (target.exists()) target = File(target.parentFile, "${target.nameWithoutExtension} (restaurado)" +
                (if (target.extension.isNotEmpty()) ".${target.extension}" else ""))
        target.parentFile?.mkdirs()
        move(File(dir, e.id), target)
        save(list().filter { it.id != e.id })
    }

    @Synchronized
    fun deleteForever(e: Entry) {
        File(dir, e.id).deleteRecursively()
        save(list().filter { it.id != e.id })
    }

    @Synchronized
    fun empty() = list().forEach { deleteForever(it) }

    @Synchronized
    fun purgeOlderThan(days: Int) {
        val limit = System.currentTimeMillis() - days * 86_400_000L
        list().filter { it.deletedAt < limit }.forEach { deleteForever(it) }
    }
}
