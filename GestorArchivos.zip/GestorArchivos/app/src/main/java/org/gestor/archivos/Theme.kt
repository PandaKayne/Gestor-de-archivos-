package org.gestor.archivos

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

private class Accent(
    val p: Color, val onP: Color, val pc: Color, val onPc: Color,
    val dp: Color, val dOnP: Color, val dpc: Color, val dOnPc: Color
)

// Azul, Gris, Rojo, Verde
private val ACCENTS = listOf(
    Accent(
        Color(0xFF1565C0), Color.White, Color(0xFFD6E4FF), Color(0xFF001B3E),
        Color(0xFF9ECAFF), Color(0xFF003063), Color(0xFF00468C), Color(0xFFD6E4FF)
    ),
    Accent(
        Color(0xFF546E7A), Color.White, Color(0xFFCFD8DC), Color(0xFF263238),
        Color(0xFFB0BEC5), Color(0xFF263238), Color(0xFF455A64), Color(0xFFCFD8DC)
    ),
    Accent(
        Color(0xFFC62828), Color.White, Color(0xFFFFDAD6), Color(0xFF410002),
        Color(0xFFFFB4AB), Color(0xFF690005), Color(0xFF93000A), Color(0xFFFFDAD6)
    ),
    Accent(
        Color(0xFF2E7D32), Color.White, Color(0xFFC8E6C9), Color(0xFF002106),
        Color(0xFF81C784), Color(0xFF00390A), Color(0xFF1B5E20), Color(0xFFC8E6C9)
    )
)

/** accent: 0 predeterminado, 1 azul, 2 gris, 3 rojo, 4 verde. */
fun appColors(dark: Boolean, accent: Int): ColorScheme {
    if (accent <= 0 || accent > ACCENTS.size) return if (dark) darkColorScheme() else lightColorScheme()
    val a = ACCENTS[accent - 1]
    return if (dark) {
        darkColorScheme(
            primary = a.dp, onPrimary = a.dOnP, primaryContainer = a.dpc, onPrimaryContainer = a.dOnPc,
            secondary = a.dp, onSecondary = a.dOnP, secondaryContainer = a.dpc, onSecondaryContainer = a.dOnPc
        )
    } else {
        lightColorScheme(
            primary = a.p, onPrimary = a.onP, primaryContainer = a.pc, onPrimaryContainer = a.onPc,
            secondary = a.p, onSecondary = a.onP, secondaryContainer = a.pc, onSecondaryContainer = a.onPc
        )
    }
}
