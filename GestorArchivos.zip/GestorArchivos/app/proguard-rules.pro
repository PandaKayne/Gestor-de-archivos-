# Las librerías con reflexión o recursos se conservan completas; el resto se reduce.
-ignorewarnings
-keep class com.tom_roush.** { *; }
-keep class com.github.junrar.** { *; }
-keep class org.apache.commons.compress.** { *; }
-keep class org.tukaani.** { *; }
-dontwarn org.slf4j.**
